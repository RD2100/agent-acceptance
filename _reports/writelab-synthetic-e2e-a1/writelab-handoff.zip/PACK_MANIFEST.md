# WriteLab Paper Handoff Packet

Handoff ID: `WRITELAB-HANDOFF-06ea9bee-9695-43f5-a1b5-8496858b54ef`

Files:

- `WRITELAB_HANDOFF.yaml`
- `DIAGNOSIS_RESULT.json`
- `PRIVACY_ATTESTATION.yaml`
- `PACK_MANIFEST.md`

Privacy statement: metadata-only export; original paragraph text, text spans, rewrite text, identities, raw transcript, and external upload traces are not included.
