# Contracts

Normative JSON schemas consumed by dev-frame-opencode and any automation agent.

## Schema Index

| Schema | Purpose | Key Rules |
|--------|---------|-----------|
| `FLOW_OUTCOME.schema.json` | Three-layer flow state (transport/business/dispatch) | `terminal=false` requires `next_task_spec_path` or `required_next_action`; `ready_to_dispatch` ≠ `dispatched` |
| `TASKSPEC.schema.json` | Machine-readable task specification | Must be JSON, not Markdown-only; `high_risk=true` triggers `human_required` |
| `DISPATCH_RESULT.schema.json` | Dispatch operation result | Distinguishes 6 dispatch states; `ready_to_dispatch` and `taskspec_generated` are non-terminal |

## Usage

These schemas are the single source of truth. dev-frame-opencode MUST validate its output against these schemas. Any automation that reads flow state MUST use these schemas, not Markdown reports.

## Precedence

Contracts > Policies > Conventions. If a policy contradicts a contract, the contract wins.
