# Policies

Normative policy documents. These define behavioral rules that complement the JSON schemas.

## Policy Index

| Policy | Purpose | Priority |
|--------|---------|----------|
| `TERMINAL_STATE_POLICY.md` | Defines when terminal=true is valid; when false, agent MUST continue | P0 |
| `DISPATCHER_POLICY.md` | Dispatcher must produce actionable DISPATCH_RESULT; not just suggestions | P0 |
| `AUTONOMOUS_PROGRESS_POLICY.md` | What can auto-advance vs what requires human | P0 |
| `HUMAN_REQUIRED_TAXONOMY.md` | 8-category taxonomy for human_required reasons | P1 |
| `STAGE_GATE_POLICY.md` | Gate definitions and stage advancement conditions | P0 |
| `EVIDENCE_PACK_CONTRACT.md` | Minimum evidence pack requirements, manifest format | P1 |

## Relationship to Contracts

- **Contracts** (schemas/) define WHAT the data must look like
- **Policies** (policies/) define HOW automation must behave
- If a policy contradicts a contract, the contract wins (contracts are machine-enforceable)
- Policies provide the rationales and decision matrices that contracts reference

## Precedence

Within policies: P0 policies override P1 policies.
