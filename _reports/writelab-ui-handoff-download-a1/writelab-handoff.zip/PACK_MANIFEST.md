# WriteLab Paper Handoff Packet

Handoff ID: `WRITELAB-HANDOFF-522e35ef-c45a-43f8-94cf-1aea34d6d625`

Files:

- `WRITELAB_HANDOFF.yaml`
- `DIAGNOSIS_RESULT.json`
- `PRIVACY_ATTESTATION.yaml`
- `PACK_MANIFEST.md`

Privacy statement: metadata-only export; original paragraph text, text spans, rewrite text, identities, raw transcript, and external upload traces are not included.
