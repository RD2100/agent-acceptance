# WriteLab Paper Handoff Packet

Handoff ID: `WRITELAB-HANDOFF-7a15daed-739f-42e0-bb22-4cd2378347ef`

Files:

- `WRITELAB_HANDOFF.yaml`
- `DIAGNOSIS_RESULT.json`
- `PRIVACY_ATTESTATION.yaml`
- `PACK_MANIFEST.md`

Privacy statement: metadata-only export; original paragraph text, text spans, rewrite text, identities, raw transcript, and external upload traces are not included.
