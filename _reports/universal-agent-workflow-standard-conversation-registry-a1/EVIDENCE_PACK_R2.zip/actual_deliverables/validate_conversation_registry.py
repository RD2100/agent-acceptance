#!/usr/bin/env python3
"""validate_conversation_registry.py — Standalone validator for AWSP Conversation Registry bindings.

Validates the structure, schema, and policy compliance of conversation registry
binding JSON files per AWSP v1.3.0.

Checks performed:
1. File existence
2. Valid JSON parsing
3. schema_version presence
4. project_root match (if provided)
5. default_conversation_policy presence
6. bindings is a list
7. Per-binding: agent_id, role, duplicate detection, binding_status,
   active-status requirements, capture_policy completeness
8. Schema-based validation against CONVERSATION_REGISTRY.schema.json
9. Optional task_id scope validation
10. Optional run_id recording

Usage:
    python scripts/validate_conversation_registry.py path/to/binding.json
    python scripts/validate_conversation_registry.py path/to/binding.json --project-root /my/project
    python scripts/validate_conversation_registry.py path/to/binding.json --task-id task-a1 --run-id run-123
"""

import argparse
import fnmatch
import json
import sys
from pathlib import Path

AWSP_VERSION = "1.3.0"

REPO = Path(__file__).resolve().parent.parent

ALLOWED_STATUSES = {
    "pending_manual_binding",
    "active",
    "paused",
    "retired",
    "invalid",
}

ALLOWED_ROLES = {
    "reviewer",
    "executor",
    "observer",
    "orchestrator",
}

REQUIRED_CAPTURE_FIELDS = [
    "must_match_run_id",
    "must_match_task_id",
    "must_include_end_marker",
    "forbid_last_message_only_capture",
]


def _normalize_path(p: str) -> str:
    """Normalize a path string: forward slashes, strip trailing slash."""
    return str(p).replace("\\", "/").rstrip("/")


def validate_binding(
    binding_path: str,
    project_root: str | None = None,
    task_id: str | None = None,
    run_id: str | None = None,
) -> dict:
    """Validate an AWSP Conversation Registry binding file.

    Args:
        binding_path: Path to the binding JSON file.
        project_root: Optional project root to cross-check against the
            binding's declared project_root field.
        task_id: Optional task ID to validate against allowed_task_scope.
        run_id: Optional run ID to record in result details.

    Returns:
        dict with keys: valid (bool), errors (list[str]),
        warnings (list[str]), details (dict).
    """
    errors: list[str] = []
    warnings: list[str] = []
    details: dict = {
        "awsp_version": AWSP_VERSION,
        "binding_path": str(binding_path),
    }

    # ------------------------------------------------------------------
    # 1. File existence
    # ------------------------------------------------------------------
    bp = Path(binding_path)
    if not bp.exists():
        errors.append(f"Binding file not found: {bp}")
        return {"valid": False, "errors": errors, "warnings": warnings, "details": details}

    # ------------------------------------------------------------------
    # 2. Parse JSON
    # ------------------------------------------------------------------
    try:
        data = json.loads(bp.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        errors.append(f"Invalid JSON: {exc}")
        return {"valid": False, "errors": errors, "warnings": warnings, "details": details}

    details["parsed"] = True

    # ------------------------------------------------------------------
    # 3. schema_version
    # ------------------------------------------------------------------
    if "schema_version" not in data:
        errors.append("Missing required field: schema_version")
    else:
        details["schema_version"] = data["schema_version"]

    # ------------------------------------------------------------------
    # 4. project_root match
    # ------------------------------------------------------------------
    if project_root is not None:
        binding_project_root = data.get("project_root")
        if binding_project_root is None:
            errors.append("Binding does not declare project_root")
        else:
            norm_expected = _normalize_path(project_root)
            norm_actual = _normalize_path(binding_project_root)
            if norm_expected != norm_actual:
                errors.append(
                    f"project_root mismatch: expected '{norm_expected}', "
                    f"got '{norm_actual}'"
                )
            details["project_root_checked"] = True

    # ------------------------------------------------------------------
    # 5. default_conversation_policy
    # ------------------------------------------------------------------
    if "default_conversation_policy" not in data:
        errors.append("Missing required field: default_conversation_policy")

    # ------------------------------------------------------------------
    # 6. bindings is a list
    # ------------------------------------------------------------------
    bindings = data.get("bindings")
    if bindings is None:
        errors.append("Missing required field: bindings")
        return {"valid": False, "errors": errors, "warnings": warnings, "details": details}

    if not isinstance(bindings, list):
        errors.append("Field 'bindings' must be a list")
        return {"valid": False, "errors": errors, "warnings": warnings, "details": details}

    details["binding_count"] = len(bindings)

    # ------------------------------------------------------------------
    # 7. Per-binding validation
    # ------------------------------------------------------------------
    seen_agent_ids: set[str] = set()

    for idx, binding in enumerate(bindings):
        prefix = f"bindings[{idx}]"

        if not isinstance(binding, dict):
            errors.append(f"{prefix}: entry is not a JSON object")
            continue

        # agent_id presence and non-empty
        agent_id = binding.get("agent_id")
        if not agent_id:
            errors.append(f"{prefix}: missing or empty agent_id")
        else:
            # Duplicate agent_id detection
            if agent_id in seen_agent_ids:
                errors.append(f"{prefix}: duplicate agent_id '{agent_id}'")
            seen_agent_ids.add(agent_id)

        # role field (v1.3.0)
        role = binding.get("role")
        if not role:
            errors.append(f"{prefix}: missing or empty role")
        elif role not in ALLOWED_ROLES:
            errors.append(
                f"{prefix}: invalid role '{role}' "
                f"(allowed: {', '.join(sorted(ALLOWED_ROLES))})"
            )

        # binding_status
        status = binding.get("binding_status")
        if status is None:
            errors.append(f"{prefix}: missing binding_status")
        elif status not in ALLOWED_STATUSES:
            errors.append(
                f"{prefix}: invalid binding_status '{status}' "
                f"(allowed: {', '.join(sorted(ALLOWED_STATUSES))})"
            )

        # Active bindings must have chat_url or conversation_id
        if status == "active":
            has_chat_url = bool(binding.get("chat_url"))
            has_conv_id = bool(binding.get("conversation_id"))
            if not has_chat_url and not has_conv_id:
                errors.append(
                    f"{prefix}: active binding must have chat_url or conversation_id"
                )

        # capture_policy
        capture_policy = binding.get("capture_policy")
        if capture_policy is None:
            errors.append(f"{prefix}: missing capture_policy")
        elif not isinstance(capture_policy, dict):
            errors.append(f"{prefix}: capture_policy must be an object")
        else:
            for field in REQUIRED_CAPTURE_FIELDS:
                if field not in capture_policy:
                    errors.append(
                        f"{prefix}: capture_policy missing field '{field}'"
                    )
                elif capture_policy[field] is not True:
                    errors.append(
                        f"{prefix}: capture_policy.{field} must be true (boolean), "
                        f"got {json.dumps(capture_policy[field])}"
                    )

    # ------------------------------------------------------------------
    # 8. Schema-based validation against CONVERSATION_REGISTRY.schema.json
    # ------------------------------------------------------------------
    schema_path = bp.parent / "CONVERSATION_REGISTRY.schema.json"
    if schema_path.exists():
        try:
            schema_data = json.loads(schema_path.read_text(encoding="utf-8"))
            details["schema_file_loaded"] = True
            details["schema_path"] = str(schema_path)

            # Verify it is a real JSON Schema
            for sf in ["$schema", "type", "properties", "required"]:
                if sf not in schema_data:
                    errors.append(
                        f"CONVERSATION_REGISTRY.schema.json missing JSON Schema field: {sf}"
                    )

            schema_required = schema_data.get("required", [])
            schema_properties = schema_data.get("properties", {})

            # Validate each binding against schema
            for idx, binding in enumerate(bindings):
                if not isinstance(binding, dict):
                    continue
                bprefix = f"bindings[{idx}]"

                # Note: schema 'required' defines the full registry entry contract.
                # Binding templates may omit runtime fields (project_id, created_at, etc.)
                # We only enforce schema-required fields that are present in the binding
                # (structural validation) plus enum/const constraints.

                # Validate enum constraints from schema properties
                for field_name, field_schema in schema_properties.items():
                    if field_name not in binding:
                        continue
                    if "enum" in field_schema:
                        allowed = field_schema["enum"]
                        if binding[field_name] not in allowed:
                            errors.append(
                                f"{bprefix}: {field_name} value "
                                f"'{binding[field_name]}' not in schema enum {allowed}"
                            )

                # Validate capture_policy against schema capture_policy properties
                if "capture_policy" in schema_properties:
                    cp_schema = schema_properties["capture_policy"]
                    cp_required = cp_schema.get("required", [])
                    cp_props = cp_schema.get("properties", {})
                    cp_actual = binding.get("capture_policy")
                    if isinstance(cp_actual, dict):
                        for cp_req in cp_required:
                            if cp_req not in cp_actual:
                                errors.append(
                                    f"{bprefix}: capture_policy missing "
                                    f"schema-required field '{cp_req}'"
                                )
                        # Check const constraints
                        for cp_field, cp_field_schema in cp_props.items():
                            if cp_field in cp_actual and "const" in cp_field_schema:
                                expected = cp_field_schema["const"]
                                if cp_actual[cp_field] is not expected:
                                    errors.append(
                                        f"{bprefix}: capture_policy.{cp_field} "
                                        f"must be {json.dumps(expected)} per schema, "
                                        f"got {json.dumps(cp_actual[cp_field])}"
                                    )

            # Active binding conditional (if/then in schema)
            # Already checked in section 7, but confirm schema defines the conditional
            if "if" not in schema_data or "then" not in schema_data:
                warnings.append(
                    "CONVERSATION_REGISTRY.schema.json missing if/then conditional "
                    "for active binding requirements"
                )

        except json.JSONDecodeError as e:
            errors.append(f"CONVERSATION_REGISTRY.schema.json is invalid JSON: {e}")
            details["schema_file_loaded"] = False
    else:
        warnings.append(
            "CONVERSATION_REGISTRY.schema.json not found alongside binding file; "
            "schema-based validation skipped"
        )
        details["schema_file_loaded"] = False

    # ------------------------------------------------------------------
    # 9. task_id scope validation
    # ------------------------------------------------------------------
    if task_id is not None:
        details["task_id"] = task_id
        task_matched = False
        for idx, binding in enumerate(bindings):
            if not isinstance(binding, dict):
                continue
            allowed_scope = binding.get("allowed_task_scope")
            if allowed_scope is None:
                continue
            # allowed_task_scope can be a string pattern or list of patterns
            patterns = (
                allowed_scope
                if isinstance(allowed_scope, list)
                else [allowed_scope]
            )
            for pattern in patterns:
                if isinstance(pattern, str) and fnmatch.fnmatch(task_id, pattern):
                    task_matched = True
                    break
            if task_matched:
                break

        if not task_matched:
            warnings.append(
                f"task_id '{task_id}' did not match any binding's allowed_task_scope"
            )

    # ------------------------------------------------------------------
    # 10. run_id recording
    # ------------------------------------------------------------------
    if run_id is not None:
        details["run_id"] = run_id

    valid = len(errors) == 0
    return {"valid": valid, "errors": errors, "warnings": warnings, "details": details}


def main() -> None:
    """CLI entry point: parse arguments, validate, and emit JSON result."""
    parser = argparse.ArgumentParser(
        description="Validate AWSP Conversation Registry binding files."
    )
    parser.add_argument(
        "binding_path",
        help="Path to the conversation registry binding JSON file.",
    )
    parser.add_argument(
        "--project-root",
        default=None,
        help="Project root directory to cross-check against the binding.",
    )
    parser.add_argument(
        "--task-id",
        default=None,
        help="Task ID to validate against allowed_task_scope patterns.",
    )
    parser.add_argument(
        "--run-id",
        default=None,
        help="Run ID to record in validation details.",
    )
    args = parser.parse_args()

    result = validate_binding(
        binding_path=args.binding_path,
        project_root=args.project_root,
        task_id=args.task_id,
        run_id=args.run_id,
    )

    print(json.dumps(result, indent=2, ensure_ascii=False))
    sys.exit(0 if result["valid"] else 1)


if __name__ == "__main__":
    main()
