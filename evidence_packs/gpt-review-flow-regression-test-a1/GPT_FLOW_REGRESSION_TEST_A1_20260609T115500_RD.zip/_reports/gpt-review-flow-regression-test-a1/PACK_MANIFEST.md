# PACK_MANIFEST — GPT-REVIEW-FLOW-REGRESSION-TEST-A1

| Field | Value |
|-------|-------|
| task_id | GPT-REVIEW-FLOW-REGRESSION-TEST-A1 |
| run_id | GPT_REVIEW_FLOW_REGRESSION_TEST_A1_REVIEW_20260609T115500_RD |
| generated_at | 2026-06-09T11:55:00.776883+08:00 |
| pack_dir | gpt-review-flow-regression-test-a1 |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\gpt-review-flow-regression-test-a1\EXECUTION_REPORT.md` | core | `10b3ebcb6c7a52e9...` | 8124 |
| 2 | `_reports\gpt-review-flow-regression-test-a1\GPT_REVIEW_PROMPT.md` | core | `24ae2675f002f474...` | 2485 |
| 3 | `tests\conftest.py` | test | `4bbbc60d4e95b7ec...` | 5083 |
| 4 | `tests\test_verify_gpt_reply.py` | test | `c9f68e502c31da6c...` | 9326 |
| 5 | `tests\test_pre_gpt_review_gate.py` | test | `8b4298732c4d2970...` | 7765 |
| 6 | `scripts\verify_gpt_reply.py` | reference | `68571359abb8cd42...` | 4884 |
| 7 | `scripts\pre_gpt_review_gate.py` | reference | `71ad725f1f32a715...` | 1705 |
| 8 | `scripts\evidence_pack_linter.py` | reference | `e560844a599f0731...` | 2910 |
| 9 | `_reports\process-state-machine-define-a1\PROCESS_STATE_MACHINE.json` | reference | `55d1709882d4677b...` | 12188 |
