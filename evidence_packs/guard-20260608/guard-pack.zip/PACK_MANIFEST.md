| path | bytes | sha256 |
|---|---:|---|
| GPT_RESULT.txt | 3924 | 4d7996199f2aa33b20868a974202285d89e4b837ab21bb60d8f027c32d73f85b |
| GUARD_FAIL_CLOSED.txt | 387 | df6a0de6f01b354730f21a17d3c7de561b840246affd27145779c0b6c3f8e7eb |
| GUARD_TEST_OUTPUT.txt | 680 | 4b7d7302027c155cc20fabadec8bc5cd1b2269734a516d4db5e9d07d3964f5c6 |
| _submit.py | 3091 | 74c25e50b5ebce9c75ca4840469de234c99b021fa47d0b0bcfcce109b8835f19 |
| actual_deliverables/verify_gpt_reply.py | 3224 | 4034a86f67c8f113c4ba005b2d9cae6a9e10dc639cba3716427afd235c8ea9b7 |
| PACK_MANIFEST.md | self | self_excluded |
