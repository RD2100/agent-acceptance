# PACK_MANIFEST — UNIVERSAL-AGENT-WORKFLOW-STANDARD-AGENT-CONFIG-SCAFFOLD-A1

| Field | Value |
|-------|-------|
| task_id | UNIVERSAL-AGENT-WORKFLOW-STANDARD-AGENT-CONFIG-SCAFFOLD-A1 |
| run_id | UNIVERSAL_AGENT_WORKFLOW_STANDARD_AGENT_CONFIG_SCAFFOLD_A1_20260609T154821_RD |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\universal-agent-workflow-standard-agent-config-scaffold-a1\EXECUTION_REPORT.md` | core | `f1a8598ce518d03f…` | 2060 |
| 2 | `_reports\universal-agent-workflow-standard-agent-config-scaffold-a1\GPT_REVIEW_PROMPT.md` | core | `bacf407b5a000cc9…` | 2489 |
| 3 | `_reports\universal-agent-workflow-standard-agent-config-scaffold-a1\CLOSURE_REPORT.md` | core | `4a657f18f77fc6b3…` | 1948 |
| 4 | `_reports\universal-agent-workflow-standard-agent-config-scaffold-a1\SAFETY_ATTESTATION.md` | core | `077ea8e5c9ace2c3…` | 1526 |
| 5 | `scripts\validate_run_id_consistency.py` | deliverable | `9127001b253aed2f…` | 9793 |
| 6 | `scripts\awsp_scaffold.py` | deliverable | `260892e61e3b5c18…` | 17266 |
| 7 | `tests\test_validate_run_id_consistency.py` | test | `3229a3857931210b…` | 9481 |
| 8 | `tests\test_cross_project_scaffold.py` | test | `d6f842667824ee7e…` | 22014 |
| 9 | `docs\AGENT_WORKFLOW_STANDARD.md` | documentation | `8d0db7208c029e17…` | 8214 |
| 10 | `_reports\universal-agent-workflow-standard-agent-config-scaffold-a1\TARGET_TEST_OUTPUT.txt` | test_output | `52461988f3f6162d…` | 6504 |
| 11 | `_reports\universal-agent-workflow-standard-agent-config-scaffold-a1\FULL_SUITE_OUTPUT.txt` | test_output | `28fdca0dd6aa9011…` | 11603 |
| 12 | `PACK_MANIFEST.md` | core | self | - |

## Tests
- Target: 49 passed / 49 total
- Suite: 540 passed / 540 total
