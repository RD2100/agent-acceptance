## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-AGENT-CONFIG-SCAFFOLD-A1 R1

You are reviewing the R1 deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-AGENT-CONFIG-SCAFFOLD-A1**.

**Task ID**: {{TASK_ID}}
**Run ID**: {{RUN_ID}}

### R3 Limitations Addressed

1. **awsp_scaffold.py generates .agent/ governance components**: Now creates .agent/REQUIRED_READS.json, .agent/PROJECT_AGENT_CONFIG.json, .agent/GATE_CONFIG.json, .agent/startup_proof_template.json in addition to the basic directory structure.

2. **validate_scaffold() verifies project_root**: Now checks .awsp.json project_root matches actual project root directory (normalized comparison).

3. **AWSP_DIRECTORIES includes .agent/**: The standard directory list now includes ".agent", and validate_scaffold() checks for .agent/ governance config files with schema_version.

4. **AWSP v1.2.0 documentation**: AGENT_WORKFLOW_STANDARD.md updated to v1.2.0 covering .agent/ governance config scaffold, validation, and cross-project deployment.

### R1 Deliverables

1. **scripts/awsp_scaffold.py** (~400 lines)
   - AWSP_VERSION = "1.2.0"
   - AWSP_DIRECTORIES includes ".agent"
   - 4 .agent/ template files in AWSP_TEMPLATES
   - validate_scaffold() checks project_root, .agent/ files, schema_version
   - 35 tests

2. **tests/test_cross_project_scaffold.py** (35 tests)
   - TestCrossProjectParameterization (3)
   - TestPromptTemplateValidation (4)
   - TestAWSPScaffold (8)
   - TestValidateScaffoldContent (6)
   - TestStrictVerdictCheck (3)
   - TestAgentConfigScaffold (5): directory, files, version, gates, governance flags
   - TestValidateAgentConfig (6): valid, missing files, root mismatch, invalid JSON, schema_version, AWSP_DIRECTORIES

3. **docs/AGENT_WORKFLOW_STANDARD.md** — AWSP v1.2.0

### Validation Results

- **Target tests**: 49 passed / 49 total
- **Full suite**: 540 passed / 540 total

### Review Criteria

1. Scaffold generates .agent/ directory with 4 governance config files?
2. validate_scaffold() checks project_root matches actual root?
3. validate_scaffold() checks .agent/ files exist and have schema_version?
4. AWSP_DIRECTORIES includes ".agent"?
5. 49 target tests pass? Full suite 540 passes?
6. Documentation updated to v1.2.0?

### Expected Verdict Format

```
overall_judgment: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
