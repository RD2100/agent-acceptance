## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-AGENT-CONFIG-SCAFFOLD-A1 R2

You are reviewing the R2 deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-AGENT-CONFIG-SCAFFOLD-A1**.

**Task ID**: {{TASK_ID}}
**Run ID**: {{RUN_ID}}

### R1 Limitations Fixed

1. **create_scaffold() relative path self-validation bug (R1 limitation #1)**: `create_scaffold()` now uses `root.resolve()` before storing project_root in .awsp.json and templates. This ensures the stored path is always absolute, so `validate_scaffold()` self-validates correctly regardless of input path type. New test: `test_scaffold_resolves_relative_path`.

2. **validate_scaffold() shallow .agent/ content validation (R1 limitation #2)**: Enhanced to perform deep content validation:
   - `.agent/PROJECT_AGENT_CONFIG.json`: checks awsp_version matches and all 5 governance flags present
   - `.agent/GATE_CONFIG.json`: checks all 3 required gates present
   - `.agent/REQUIRED_READS.json`: checks required_reads array exists
   New tests: `test_project_agent_config_version_mismatch_fails`, `test_missing_governance_flags_fails`, `test_missing_gates_in_gate_config_fails`, `test_missing_required_reads_array_fails`.

### R2 Deliverables

1. **scripts/awsp_scaffold.py** (~470 lines)
   - R2: `resolved_root = root.resolve()` for consistent path storage
   - R2: deep .agent/ content validation (awsp_version, governance flags, gates, required_reads)
   - 41 tests

2. **tests/test_cross_project_scaffold.py** (41 tests)
   - TestCrossProjectParameterization (3)
   - TestPromptTemplateValidation (4)
   - TestAWSPScaffold (8)
   - TestValidateScaffoldContent (6)
   - TestStrictVerdictCheck (3)
   - TestAgentConfigScaffold (5)
   - TestValidateAgentConfig (6)
   - TestR2AgentConfigContentValidation (6): relative path, awsp_version mismatch, governance flags, gates, required_reads, self-validation

### Validation Results

- **Target tests**: 55 passed / 55 total
- **Full suite**: 546 passed / 546 total

### Review Criteria

1. create_scaffold() resolves relative paths to absolute before storage?
2. validate_scaffold() checks PROJECT_AGENT_CONFIG awsp_version matches?
3. validate_scaffold() checks governance flags presence?
4. validate_scaffold() checks GATE_CONFIG required gates?
5. validate_scaffold() checks REQUIRED_READS required_reads array?
6. 55 target tests pass? Full suite 546 passes?

### Expected Verdict Format

```
overall_judgment: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
