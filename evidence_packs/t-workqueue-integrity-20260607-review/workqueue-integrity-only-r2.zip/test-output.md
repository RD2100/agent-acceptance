﻿# Test Output

## 1. WorkQueue self-test
- Command: `powershell -ExecutionPolicy Bypass -File scripts/Test-WorkQueue.ps1`
- Expected: missing batch-local-quality blocker removed
- Result: PASS (queue references now resolve)
- Evidence: workqueue-selftest-output.txt

## 2. Shared active local-quality batch
- Command: `powershell -ExecutionPolicy Bypass -File scripts/Run-Batch.ps1 -TaskFile scripts/examples/batch-local-quality.json`
- Expected: all Tier 0 checks pass
- Actual: batch still reports FAILED with alternating tasks marked `exit=2`
- Evidence:
  - batch-local-quality-output.txt
  - runs/powershell-acceptance/batch-local-quality/batch-report.md
  - runs/powershell-acceptance/batch-local-quality/batch-result.json
  - per-task stdout.log / exit.code files

## 3. Local-quality queue execution
- Command: `powershell -ExecutionPolicy Bypass -File scripts/Run-WorkQueue.ps1 -QueueFile agent-workqueue/local-quality.queue.json`
- Expected: queue passes if shared batch passes
- Actual: queue fails because batch exits 2
- Evidence:
  - queue-local-quality-output.txt
  - runs/powershell-acceptance/workqueue/local-quality-queue/queue-report.md

## 4. Key finding
- The missing `scripts/examples/batch-local-quality.json` defect is fixed.
- The remaining blocker is now runner-side behavior, not queue reference integrity.
- Direct task logs show several failed batch tasks actually produced passing pytest output and `exit.code = 0`, which suggests a runner/reporting mismatch inside Run-Batch / WorkQueue execution flow.
- Current task scope does not allow editing `scripts/Run-Batch.ps1` or `scripts/Run-WorkQueue.ps1`, so the module cannot honestly be marked pass within the existing boundary.
