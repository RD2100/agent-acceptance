﻿task_id: t-workqueue-integrity-20260601
review_type: blocked_scope_reassessment
status: ready_for_review
final_status: ready_for_review

# WorkQueue Integrity Review Pack

This pack captures a partial fix plus a boundary mismatch.

What is fixed:
- `scripts/examples/batch-local-quality.json` now exists again.
- Queue JSONs reference a real active batch file.
- `Test-WorkQueue.ps1` now passes.

What is still blocked:
- Running the shared local-quality batch still produces false failures inside `Run-Batch.ps1` / `Run-WorkQueue.ps1` reporting.
- Direct per-task logs show some tasks pass with `exit.code = 0`, while batch summary records them as `exit=2` failures.
- The current TaskSpec does not allow editing `scripts/Run-Batch.ps1` or `scripts/Run-WorkQueue.ps1`, so the remaining defect is outside scope.

Request:
- Review whether the correct next task is to expand/supersede the current WorkQueue task into a runner-integrity task that includes `Run-Batch.ps1` and `Run-WorkQueue.ps1`.
