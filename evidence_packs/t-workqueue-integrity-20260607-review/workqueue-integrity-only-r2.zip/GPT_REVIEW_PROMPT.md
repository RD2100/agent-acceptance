﻿Please review the attached WorkQueue integrity evidence pack.

Review focus:
- Verify that the missing batch-local-quality.json defect is fixed.
- Verify that Test-WorkQueue now passes.
- Verify that batch-local-quality and local-quality queue execution are still blocked by runner/reporting behavior rather than queue reference integrity.
- Determine whether the correct next task should supersede/expand scope to include scripts/Run-Batch.ps1 and scripts/Run-WorkQueue.ps1.
- Return the next task recommendation and whether execute_immediately is authorized.

Return structured output:
overall_judgment: accepted|blocked|human_required
reviewer_type: gpt
task_id: t-workqueue-integrity-20260601
evidence_pack_reviewed: true
blocking_issues: []
required_fixes: []
next_task_authorization:
  authorized: yes|no
  execute_immediately: yes|no
  ask_before_starting: yes|no
  recommended_task_id: ""

End with END_OF_GPT_RESPONSE.
