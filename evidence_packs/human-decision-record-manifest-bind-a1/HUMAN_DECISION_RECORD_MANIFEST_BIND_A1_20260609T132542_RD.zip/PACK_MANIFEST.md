# PACK_MANIFEST — HUMAN-DECISION-RECORD-MANIFEST-BIND-A1

| Field | Value |
|-------|-------|
| task_id | HUMAN-DECISION-RECORD-MANIFEST-BIND-A1 |
| run_id | HUMAN_DECISION_RECORD_MANIFEST_BIND_A1_20260609T132542_RD |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\human-decision-record-manifest-bind-a1\EXECUTION_REPORT.md` | core | `9ba72ee7347b825c…` | 1957 |
| 2 | `_reports\human-decision-record-manifest-bind-a1\GPT_REVIEW_PROMPT.md` | core | `4f7ea9a18ab0bc69…` | 1528 |
| 3 | `scripts\human_decision_record.py` | deliverable | `152adf0f2e3094f0…` | 12322 |
| 4 | `scripts\state_machine_runtime.py` | deliverable | `fe0a49b71d6dfbfc…` | 13717 |
| 5 | `tests\test_human_decision_record.py` | test | `eaa10fdae4a655af…` | 35080 |
| 6 | `tests\test_state_machine_runtime.py` | test | `c3acab51dd678c0c…` | 17632 |
| 7 | `_reports\human-decision-record-cli-t10-hash-integrate-a1\GPT_REVIEW_RECORD_R1.json` | reference | `507435ac08c3a757…` | 1130 |
| 8 | `PACK_MANIFEST.md` | core | self | - |

## Tests
- Suite: 472 passed
