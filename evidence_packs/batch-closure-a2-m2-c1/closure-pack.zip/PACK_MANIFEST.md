# Evidence Pack - Batch R2
created_at: 2026-06-06T08:46:31Z
files_count: 13

| path | role | sha256 |
|------|------|--------|
| BYPASS_CHECK_OUTPUT.txt | evidence | ef25ddd2c78a019ce18b4a3cc9b04f6b7a92e085335f73526fa863885771f3fc |
| CLOSURE_REPORT.md | evidence | 4cda80a0eec49e65d984d4d22db3aea6976edf664cd269c5b1a43dd1febb8929 |
| MEMORY_COMPILER_OUTPUT.txt | evidence | 606f9d893037752447067e94e6f3babe764937efee52cae261902cab1a94a5de |
| MEMORY_LINT_OUTPUT.txt | evidence | e9c13e831cd4dfb72d8e9246dda565b754444fe5257e01cd5e053b51238f1892 |
| SAFETY_ATTESTATION.md | evidence | 2d05c084589bdfe2309c02d1b19049cb6cbe8c046e5ce9847870f467ffb55519 |
| TEST_OUTPUT.txt | evidence | c518ab2e1e348d5a939816ec4192f7e8b114c860037f4badb6afd7c8a0e5c0e4 |
| docs/paper-workflow-memory-rules.md | deliverable | 7ab17d535b1d39e01ecbb9cf484dbc96b0a57bb4856b6f4c233fd8336312d08a |
| hooks/pre-push.governance.ps1 | deliverable | 1646129f7946403e61ec4400eade6e270263db3f158ffa20921c96564605ea8d |
| memory/daily/2026-06-06.md | deliverable | 9b3549432e15f3a4ab5c27be1c951fc274748d5f286741e5efbbe32a5978bb0f |
| memory/knowledge/index.md | deliverable | 2c56e103794624a2c943fe70000fbbce2c7ffe63e336a7a60999d2cf11479099 |
| scripts/memory_compiler.py | deliverable | 4961c5281b0f23d403c5ec3699af1af950498b007bf668912c2c8e797293306b |
| scripts/memory_lint.py | deliverable | b6339293354831549f841f19351127f114949c9975e9ffb7c86effd3dedb0cbf |
| PACK_MANIFEST.md | pack_manifest | self_excluded |

manifest_valid: true
