Review GPT-REVIEW-QUEUE-A1.
Verify: review_queue.py creates/submits/replies/accepts/closes tickets.
One active submission limit. Fail-closed on missing evidence.
Return: overall_judgment: accepted|blocked
END_OF_GPT_RESPONSE