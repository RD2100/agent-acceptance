| path | bytes | sha256 |
|---|---:|---|
| CLOSURE_REPORT.md | 514 | 810c80338049d082f68aa4c1f8baf82aabcf7f5d121adab5162321975f54eb7a |
| GPT_REVIEW_PROMPT.md | 228 | 3b8aaa55115f336850606bfaf2c844c2515d21fb580a7f5c0cbf9a6398b8a7ae |
| SAFETY_ATTESTATION.md | 58 | 50bbbed9e499344715f8363738412ca59cd36ead5667fdbe8dcc5bf0bda272a4 |
| actual_deliverables/schemas/review_ticket.schema.json | 1571 | d91eff5ab768b41ce24bc0171e61cd6fadd6f1df042f4c693a354d03070026c3 |
| actual_deliverables/scripts/review_queue.py | 8567 | 196da78673e3bd6363cf949ddea2654be5139ee2df984d73461ce3911f43216c |
| actual_deliverables/tests/test_review_queue.py | 3460 | e96d06a87eadd29995dc4aea183fa45ba495765ae07f14d34ed60f20b2e1f9b2 |
| PACK_MANIFEST.md | self | self_excluded |
