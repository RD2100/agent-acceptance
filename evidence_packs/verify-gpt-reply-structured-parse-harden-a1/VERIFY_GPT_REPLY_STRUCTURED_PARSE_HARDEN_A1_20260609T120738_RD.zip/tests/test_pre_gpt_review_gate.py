"""test_pre_gpt_review_gate.py — Regression tests for pre_gpt_review_gate.py + evidence_pack_linter.py.

Test cases per HANDOFF_WORKFLOW_HARDENING_PLAN.md section 5.5:
  PGT-001: Complete evidence pack -> PASS
  PGT-002: Missing manifest -> FAIL
  PGT-003: Hash inconsistency -> FAIL (not fully testable without real hashes)
  PGT-004: Empty evidence pack -> FAIL
  PGT-005: Invalid reference -> FAIL (not fully testable)
  PGT-006: Thin deliverables -> WARNING
"""

import json
import pytest
from pathlib import Path

from evidence_pack_linter import lint
from pre_gpt_review_gate import gate


class TestEvidencePackLinter:
    """Tests for evidence_pack_linter.lint()."""

    def test_pgt001_complete_pack(self, valid_evidence_pack):
        """PGT-001: Complete evidence pack should PASS."""
        result = lint(valid_evidence_pack)
        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_pgt002_missing_manifest(self, pack_missing_manifest):
        """PGT-002: Pack missing PACK_MANIFEST.md should FAIL."""
        result = lint(pack_missing_manifest)
        assert result["valid"] is False
        assert any("PACK_MANIFEST.md" in e for e in result["errors"])

    def test_pgt004_empty_pack(self, empty_evidence_pack):
        """PGT-004: Empty evidence pack directory should FAIL."""
        result = lint(empty_evidence_pack)
        assert result["valid"] is False
        # Should report multiple missing files
        assert len(result["errors"]) >= 4  # CLOSURE, PROMPT, MANIFEST, SAFETY + dirs

    def test_nonexistent_directory(self, tmp_path):
        """Lint on non-existent directory should FAIL gracefully."""
        result = lint(str(tmp_path / "nonexistent"))
        assert result["valid"] is False
        assert any("not found" in e for e in result["errors"])

    def test_missing_required_files(self, tmp_path):
        """Pack missing some required files should report each missing file."""
        pack = tmp_path / "partial_pack"
        pack.mkdir()
        (pack / "CLOSURE_REPORT.md").write_text("# Closure\n")
        # Missing: GPT_REVIEW_PROMPT.md, PACK_MANIFEST.md, SAFETY_ATTESTATION.md

        result = lint(str(pack))
        assert result["valid"] is False
        missing_files = [e for e in result["errors"] if "missing required file" in e]
        assert len(missing_files) == 3

    def test_missing_required_dirs(self, tmp_path):
        """Pack missing required directories should report each."""
        pack = tmp_path / "no_dirs_pack"
        pack.mkdir()
        (pack / "CLOSURE_REPORT.md").write_text("# Closure\n")
        (pack / "GPT_REVIEW_PROMPT.md").write_text("# Prompt\n")
        (pack / "PACK_MANIFEST.md").write_text("# Manifest\n")
        (pack / "SAFETY_ATTESTATION.md").write_text("# Safety\ntrue\n")
        # Missing: actual_deliverables/, reports/

        result = lint(str(pack))
        assert result["valid"] is False
        missing_dirs = [e for e in result["errors"] if "missing required directory" in e]
        assert len(missing_dirs) == 2

    def test_empty_actual_deliverables_sd01(self, tmp_path):
        """SD-01: Empty actual_deliverables should flag summary-only risk."""
        pack = tmp_path / "sd01_pack"
        pack.mkdir()
        (pack / "CLOSURE_REPORT.md").write_text("# Closure\n")
        (pack / "GPT_REVIEW_PROMPT.md").write_text("# Prompt\n")
        (pack / "PACK_MANIFEST.md").write_text("# Manifest\n")
        (pack / "SAFETY_ATTESTATION.md").write_text("# Safety\ntrue\n")
        ad = pack / "actual_deliverables"
        ad.mkdir()  # Empty!
        reports = pack / "reports"
        reports.mkdir()

        result = lint(str(pack))
        assert any("SD-01" in e for e in result["errors"])
        assert result["summary_only_risk"] == "SD-01"

    def test_thin_deliverables_warning(self, tmp_path):
        """PGT-006: <= 3 deliverable files should generate thin evidence warning."""
        pack = tmp_path / "thin_pack"
        pack.mkdir()
        (pack / "CLOSURE_REPORT.md").write_text("# Closure\n")
        (pack / "GPT_REVIEW_PROMPT.md").write_text("# Prompt\n")
        (pack / "PACK_MANIFEST.md").write_text("# Manifest\n")
        (pack / "SAFETY_ATTESTATION.md").write_text("# Safety\ntrue\n")
        ad = pack / "actual_deliverables"
        ad.mkdir()
        (ad / "file1.py").write_text("# 1\n")
        (ad / "file2.py").write_text("# 2\n")
        reports = pack / "reports"
        reports.mkdir()
        (reports / "TEST_OUTPUT.txt").write_text("PASS\n")

        result = lint(str(pack))
        assert result["valid"] is True
        assert any("thin evidence" in w for w in result["warnings"])

    def test_safety_attestation_warning(self, tmp_path):
        """Empty or thin SAFETY_ATTESTATION should warn."""
        pack = tmp_path / "safety_pack"
        pack.mkdir()
        (pack / "CLOSURE_REPORT.md").write_text("# Closure\n")
        (pack / "GPT_REVIEW_PROMPT.md").write_text("# Prompt\n")
        (pack / "PACK_MANIFEST.md").write_text("# Manifest\n")
        (pack / "SAFETY_ATTESTATION.md").write_text("# Empty safety\n")  # No 'true'
        ad = pack / "actual_deliverables"
        ad.mkdir()
        (ad / "f.py").write_text("# f\n")
        (ad / "g.py").write_text("# g\n")
        (ad / "h.py").write_text("# h\n")
        (ad / "i.py").write_text("# i\n")
        reports = pack / "reports"
        reports.mkdir()

        result = lint(str(pack))
        assert any("SAFETY_ATTESTATION" in w for w in result["warnings"])


class TestPreGptReviewGate:
    """Tests for pre_gpt_review_gate.gate()."""

    def test_pgt001_gate_passes_valid_pack(self, valid_evidence_pack):
        """PGT-001: Gate should pass for a valid evidence pack."""
        result = gate(valid_evidence_pack)
        assert result["gate_passed"] is True
        assert len(result["errors"]) == 0
        assert "READY" in result["recommendation"]

    def test_pgt002_gate_blocks_missing_manifest(self, pack_missing_manifest):
        """PGT-002: Gate should block when manifest is missing."""
        result = gate(pack_missing_manifest)
        assert result["gate_passed"] is False
        assert "BLOCKED" in result["recommendation"]

    def test_pgt004_gate_blocks_empty_pack(self, empty_evidence_pack):
        """PGT-004: Gate should block on empty evidence pack."""
        result = gate(empty_evidence_pack)
        assert result["gate_passed"] is False
        assert len(result["errors"]) > 0

    def test_gate_extra_checks_deliverable_count(self, valid_evidence_pack):
        """Gate should report deliverable count in extra_checks."""
        result = gate(valid_evidence_pack)
        assert "deliverable_count" in result["extra_checks"]
        assert result["extra_checks"]["deliverable_count"] >= 4

    def test_gate_has_sha256_entries(self, valid_evidence_pack):
        """Gate should check manifest for SHA-256 entries."""
        result = gate(valid_evidence_pack)
        assert result["extra_checks"].get("has_sha256_entries") is True

    def test_gate_sd01_blocks_summary_only(self, tmp_path):
        """Gate should block summary-only packs (SD-01)."""
        pack = tmp_path / "sd01_gate_pack"
        pack.mkdir()
        (pack / "CLOSURE_REPORT.md").write_text("# Closure\n")
        (pack / "GPT_REVIEW_PROMPT.md").write_text("# Prompt\n")
        (pack / "PACK_MANIFEST.md").write_text("# Manifest\n")
        (pack / "SAFETY_ATTESTATION.md").write_text("# Safety\ntrue\n")
        ad = pack / "actual_deliverables"
        ad.mkdir()  # Empty
        reports = pack / "reports"
        reports.mkdir()

        result = gate(str(pack))
        assert result["gate_passed"] is False
        assert any("SD-01" in e for e in result["errors"])
