# PACK_MANIFEST — STATE-MACHINE-RUNTIME-INTEGRATE-A1

| Field | Value |
|-------|-------|
| task_id | STATE-MACHINE-RUNTIME-INTEGRATE-A1 |
| run_id | STATE_MACHINE_RUNTIME_INTEGRATE_A1_REVIEW_20260609T124546_RD |
| generated_at | 2026-06-09T12:45:46.669179+08:00 |
| pack_dir | state-machine-runtime-integrate-a1 |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\state-machine-runtime-integrate-a1\EXECUTION_REPORT.md` | core | `a477d9e5277664a2...` | 3004 |
| 2 | `_reports\state-machine-runtime-integrate-a1\GPT_REVIEW_PROMPT.md` | core | `5abe4dc8c5ab4b4d...` | 1853 |
| 3 | `scripts\state_machine_runtime.py` | deliverable | `8773e8bd122b3a9b...` | 10267 |
| 4 | `tests\test_state_machine_runtime.py` | test | `77d0c16241da94ec...` | 8460 |
| 5 | `_reports\process-state-machine-define-a1\PROCESS_STATE_MACHINE.json` | reference | `55d1709882d4677b...` | 12188 |
| 6 | `_reports\startup-read-gate-default-path-runid-harden-a1\GPT_REVIEW_RECORD_R1.json` | reference | `443b4ec8786b261a...` | 2652 |
