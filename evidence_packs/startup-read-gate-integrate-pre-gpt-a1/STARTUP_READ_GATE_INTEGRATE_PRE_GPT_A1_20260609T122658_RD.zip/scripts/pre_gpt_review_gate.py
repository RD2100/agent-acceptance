#!/usr/bin/env python3
"""
pre_gpt_review_gate.py — Gate evidence pack before CDP submission.
Runs linter + targeted checks. Blocks submission on SD-01 or missing evidence.

Integration with startup_read_gate.py (per hardening plan §5.7.3):
    If --startup-proof-path is provided, the startup read gate check runs
    as an additional pre-submission gate. The pack will be BLOCKED if the
    startup read gate fails.

Usage:
    python scripts/pre_gpt_review_gate.py <pack_dir> \
        [--startup-proof-path <proof.json>] \
        [--required-reads <NEXT_AGENT_REQUIRED_READS.json>] \
        [--strict]
"""
import json, sys, argparse
from pathlib import Path
from evidence_pack_linter import lint

REPO = Path(__file__).resolve().parent.parent

def gate(
    pack_dir: str,
    startup_proof_path: str = None,
    required_reads_path: str = None,
    strict: bool = False,
) -> dict:
    """Run pre-GPT-review gate. Returns verdict. Blocks on errors.

    Args:
        pack_dir: Path to the evidence pack directory.
        startup_proof_path: Optional path to startup proof JSON.
            If provided, startup read gate check is run.
        required_reads_path: Optional path to NEXT_AGENT_REQUIRED_READS.json.
            Defaults to repo root if not provided.
        strict: If True, startup read gate runs in strict mode.
    """
    result = lint(pack_dir)

    # Additional checks
    p = Path(pack_dir)
    extra_checks = {}

    # Actual deliverables content check
    ad = p / "actual_deliverables"
    if ad.is_dir():
        files = list(ad.rglob("*"))
        extra_checks["deliverable_count"] = len(files)
        if len(files) == 0:
            result["errors"].append("SD-01: summary-only pack — no actual deliverables")

    # Manifest hash check
    manifest = p / "PACK_MANIFEST.md"
    if manifest.exists():
        content = manifest.read_text(encoding="utf-8", errors="replace")
        extra_checks["has_sha256_entries"] = "sha256" in content.lower() or "|" in content

    # Startup read gate integration (§5.7.3)
    startup_result = None
    if startup_proof_path:
        # Import startup_read_gate dynamically
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        try:
            from startup_read_gate import gate as startup_gate
        except ImportError:
            result["errors"].append(
                "startup_read_gate.py not found — cannot run startup read check"
            )
            startup_result = None
        else:
            reads_path = required_reads_path or str(REPO / "NEXT_AGENT_REQUIRED_READS.json")

            # Extract task_id from pack manifest if possible
            task_id = ""
            if manifest.exists():
                for line in content.splitlines():
                    if "task_id" in line and "|" in line:
                        parts = [p.strip() for p in line.split("|")]
                        for part in parts:
                            if part and part != "task_id" and not part.startswith("-"):
                                task_id = part
                                break
                        break

            startup_result = startup_gate(
                task_id=task_id,
                proof_path=startup_proof_path,
                required_reads_path=reads_path,
                repo_root=str(REPO),
                strict=strict,
            )

            # Merge startup gate results
            extra_checks["startup_read_gate"] = {
                "gate_passed": startup_result["gate_passed"],
                "errors_count": len(startup_result["errors"]),
                "warnings_count": len(startup_result["warnings"]),
            }
            if "coverage_ratio" in startup_result.get("extra_checks", {}):
                extra_checks["startup_coverage_ratio"] = startup_result["extra_checks"]["coverage_ratio"]

            if not startup_result["gate_passed"]:
                for err in startup_result["errors"]:
                    result["errors"].append(f"startup_read_gate: {err}")

            # Forward startup warnings
            for w in startup_result.get("warnings", []):
                result.setdefault("warnings", []).append(f"startup_read_gate: {w}")

    # Blocking decision
    blocked = len(result["errors"]) > 0
    return {
        "gate_passed": not blocked,
        "errors": result["errors"],
        "warnings": result.get("warnings", []),
        "extra_checks": extra_checks,
        "recommendation": "READY for GPT submission" if not blocked else "BLOCKED: fix errors before CDP submit",
    }

def main():
    parser = argparse.ArgumentParser(
        description="Pre-GPT Review Gate — lint evidence pack + optional startup read check"
    )
    parser.add_argument("pack_dir", help="Path to evidence pack directory")
    parser.add_argument(
        "--startup-proof-path",
        default=None,
        help="Path to startup proof JSON (enables startup read gate check)",
    )
    parser.add_argument(
        "--required-reads",
        default=None,
        help="Path to NEXT_AGENT_REQUIRED_READS.json (default: repo root)",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        default=False,
        help="Run startup read gate in strict mode",
    )

    args = parser.parse_args()
    r = gate(
        pack_dir=args.pack_dir,
        startup_proof_path=args.startup_proof_path,
        required_reads_path=args.required_reads,
        strict=args.strict,
    )
    print(json.dumps(r, indent=2, ensure_ascii=False))
    sys.exit(0 if r["gate_passed"] else 1)

if __name__ == "__main__":
    main()
