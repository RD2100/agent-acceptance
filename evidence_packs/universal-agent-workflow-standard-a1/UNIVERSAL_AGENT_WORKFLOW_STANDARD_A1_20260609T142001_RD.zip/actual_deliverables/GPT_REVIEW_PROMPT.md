## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1 R2

You are reviewing the R2 deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1**.

### Task Definition

Per the blocking issues from R1: Fix 5 blocking issues in validate_run_id_consistency.py:
1. Fail when prompt has no {{RUN_ID}} placeholder (even without hardcoded run_id)
2. Fail when evidence pack zip is missing
3. Check for {{TASK_ID}} in prompt (required per AWSP)
4. Read PACK_MANIFEST.md and verify run_id matches run_id.txt
5. Add tests for all blocking scenarios

### R2 Deliverables

1. **`scripts/validate_run_id_consistency.py`** (updated, ~140 lines)
   - Missing {{RUN_ID}} → error (was just a detail)
   - Missing evidence pack zip → error (was silently skipped)
   - Missing {{TASK_ID}} → error (new check)
   - PACK_MANIFEST.md run_id field mismatch → error (new check)
   - Empty run_id.txt → error (new check)
   - Multi-level evidence_packs search (parent.parent and parent)

2. **`tests/test_validate_run_id_consistency.py`** (12 tests, +5 new)
   - test_missing_run_id_template_var: no {{RUN_ID}} → fail
   - test_missing_task_id_template_var: no {{TASK_ID}} → fail
   - test_missing_evidence_pack_zip: no zip → fail
   - test_manifest_run_id_mismatch: PACK_MANIFEST run_id differs → fail
   - test_empty_run_id_file: empty file → fail

### Review Criteria

1. **All R1 blocking issues resolved?**
2. **Fail-closed: are all AWSP requirements enforced as errors?**
3. **Test coverage: 12 tests sufficient?**
4. **Backward compatibility: existing 491 tests still pass?**

### Expected Verdict Format

```
verdict: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
