# Execution Report: UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1

## Task Definition

Per GPT authorization from HUMAN-DECISION-RECORD-MANIFEST-CONTENT-CROSSCHECK-A1 R1 (accepted_with_limitation):
Establish a universal agent workflow standard that addresses recurring limitations across all hardening tasks:
1. Run-ID consistency across pack artifacts (filename, prompt, GPT reply)
2. Prompt template standardization (use `{{RUN_ID}}` instead of hardcoded values)
3. Validation utility for detecting run_id inconsistencies

## Deliverables

### 1. `docs/AGENT_WORKFLOW_STANDARD.md` (new, ~70 lines)

Defines the canonical Agent Workflow Standard Protocol (AWSP) v1.0.0:
- Run-ID consistency rule: pack filename = run_id.txt = prompt {{RUN_ID}} = GPT reply run_id
- Evidence pack standard: PACK_MANIFEST.md with proper table, all files listed
- Prompt template standard: {{RUN_ID}}, {{TASK_ID}} variables, END_OF_GPT_RESPONSE marker
- Verification standard: post-reply run_id validation

### 2. `scripts/validate_run_id_consistency.py` (new, ~130 lines)

Validation utility that checks:
- `run_id.txt` exists and contains run_id
- `R1_RUN_ID.txt` matches `run_id.txt`
- Evidence pack filename contains the same run_id
- `GPT_REVIEW_PROMPT.md` uses `{{RUN_ID}}` template variable (detects hardcoded run_ids)
- GPT review result run_id matches submitted run_id

### 3. `tests/test_validate_run_id_consistency.py` (new, 7 tests)

- `test_consistent_artifacts`: all matching → pass
- `test_missing_run_id_file`: no run_id.txt → fail
- `test_hardcoded_run_id_in_prompt`: hardcoded in prompt → fail
- `test_r1_run_id_mismatch`: R1_RUN_ID.txt differs → fail
- `test_gpt_reply_run_id_mismatch`: GPT reply differs → fail
- `test_gpt_reply_run_id_matches`: all match → pass
- `test_pack_filename_check`: pack filename check

## Test Results

- **Total tests**: 498
- **Passed**: 498
- **Failed**: 0
- **New tests added**: 7

## Impact on Existing Workflow

- All existing `_build_evidence_pack.py` scripts should be updated to use `{{RUN_ID}}` in GPT_REVIEW_PROMPT.md
- All existing `_submit_gpt_review_rn.py` scripts already use `render_prompt()` which substitutes `{{RUN_ID}}`
- The validator can be run post-build to detect inconsistencies before submission
