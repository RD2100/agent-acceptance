## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1 R3

You are reviewing the R3 deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1**.

### R2 Blocking Issues Fixed

1. **Missing PACK_MANIFEST.md now fails**: Validator returns error when evidence pack directory exists but PACK_MANIFEST.md is missing (AWSP requires it).
2. **New test added**: test_missing_pack_manifest — asserts validator fails when PACK_MANIFEST.md absent.

### R3 Deliverables

1. **** (~145 lines)
   - All R1 blocking issues fixed ({{RUN_ID}}, {{TASK_ID}}, zip, manifest run_id, empty run_id)
   - All R2 blocking issues fixed (missing PACK_MANIFEST.md)
   - Multi-level evidence_packs directory search

2. **** (13 tests)
   - 13 tests covering all AWSP requirements including missing PACK_MANIFEST.md

### Review Criteria

1. All R2 blocking issues resolved?
2. PACK_MANIFEST.md absence properly fails validation?
3. 13 tests sufficient?
4. 504 full suite tests pass?

### Expected Verdict Format

```
verdict: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
