# PACK_MANIFEST - UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1

| Field | Value |
|-------|-------|
| task_id | UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1 |
| run_id | UNIVERSAL_AGENT_WORKFLOW_STANDARD_A1_20260609T142632_RD |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\universal-agent-workflow-standard-a1\EXECUTION_REPORT.md` | core | `3b8d96f5028e3037...` | 2254 |
| 2 | `_reports\universal-agent-workflow-standard-a1\GPT_REVIEW_PROMPT.md` | core | `88028b54e424e9ed...` | 1232 |
| 3 | `scripts\human_decision_record.py` | deliverable | `d3fc57a8c4342d1a...` | 19433 |
| 4 | `scripts\state_machine_runtime.py` | deliverable | `fe0a49b71d6dfbfc...` | 13717 |
| 5 | `scripts\validate_run_id_consistency.py` | deliverable | `89ceb2e0f3269dfd...` | 6802 |
| 6 | `tests\test_human_decision_record.py` | test | `eb07014775abd234...` | 56389 |
| 7 | `tests\test_state_machine_runtime.py` | test | `a91b409eb61fbc91...` | 17956 |
| 8 | `tests\test_validate_run_id_consistency.py` | test | `15157582c2991ab7...` | 8731 |
| 9 | `docs\AGENT_WORKFLOW_STANDARD.md` | documentation | `237776695049fc66...` | 1665 |
| 10 | `_reports\human-decision-record-manifest-content-crosscheck-a1\GPT_REVIEW_RECORD_R1.json` | reference | `56f5a2a6552e26cb...` | 1292 |
| 11 | `PACK_MANIFEST.md` | core | self | - |

## Tests
- Suite: 504 passed
