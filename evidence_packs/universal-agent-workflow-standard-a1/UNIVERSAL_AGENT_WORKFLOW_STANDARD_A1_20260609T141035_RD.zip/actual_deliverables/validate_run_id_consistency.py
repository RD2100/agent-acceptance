#!/usr/bin/env python3
"""validate_run_id_consistency.py — Validates run_id consistency across pack artifacts.

Checks:
1. Pack filename contains the same run_id as run_id.txt
2. GPT_REVIEW_PROMPT.md uses {{RUN_ID}} (not hardcoded)
3. GPT review result run_id matches (if result exists)

Usage:
    python scripts/validate_run_id_consistency.py --report-dir _reports/task-a1/
"""

import argparse
import re
import sys
from pathlib import Path


def validate_run_id_consistency(report_dir: str) -> dict:
    """Validate run_id consistency across all pack artifacts.

    Returns:
        dict with consistent, errors, details.
    """
    errors = []
    details = {}
    rdir = Path(report_dir)

    # 1. Read run_id from run_id.txt
    run_id_file = rdir / "run_id.txt"
    if not run_id_file.exists():
        return {"consistent": False, "errors": ["run_id.txt not found"], "details": {}}
    run_id = run_id_file.read_text(encoding="utf-8").strip()
    details["run_id_from_file"] = run_id

    # 2. Check R1_RUN_ID.txt matches
    r1_run_id_file = rdir / "R1_RUN_ID.txt"
    if r1_run_id_file.exists():
        r1_run_id = r1_run_id_file.read_text(encoding="utf-8").strip()
        details["r1_run_id"] = r1_run_id
        if r1_run_id != run_id:
            errors.append(f"R1_RUN_ID.txt ({r1_run_id}) != run_id.txt ({run_id})")

    # 3. Check evidence pack filename contains run_id
    pack_dirs = list((rdir.parent.parent / "evidence_packs").glob("*"))
    task_dir_name = rdir.name
    matching_pack_dir = None
    for pd in pack_dirs:
        if pd.name.lower() == task_dir_name.lower() or pd.name == task_dir_name:
            matching_pack_dir = pd
            break

    if matching_pack_dir:
        zips = sorted(matching_pack_dir.glob("*.zip"))
        if zips:
            pack_name = zips[-1].stem  # filename without .zip
            details["pack_filename"] = pack_name
            if run_id not in pack_name:
                errors.append(f"Pack filename ({pack_name}) does not contain run_id ({run_id})")

    # 4. Check GPT_REVIEW_PROMPT.md uses {{RUN_ID}}
    prompt_file = rdir / "GPT_REVIEW_PROMPT.md"
    if prompt_file.exists():
        prompt_content = prompt_file.read_text(encoding="utf-8")
        details["prompt_uses_template_var"] = "{{RUN_ID}}" in prompt_content
        # Check for hardcoded run_ids in expected verdict format
        hardcoded_pattern = re.findall(r'run_id:\s*\w+_\d{8}T\d{6}_\w+', prompt_content)
        if hardcoded_pattern:
            details["hardcoded_run_ids"] = hardcoded_pattern
            errors.append(
                f"GPT_REVIEW_PROMPT.md has {len(hardcoded_pattern)} hardcoded run_id(s) "
                f"instead of {{{{RUN_ID}}}} template variable"
            )

    # 5. Check GPT review result run_id matches (if available)
    for result_file in ["GPT_REVIEW_RESULT.txt", "GPT_REVIEW_RESULT_R1.txt", "GPT_REVIEW_RESULT_R2.txt"]:
        rf = rdir / result_file
        if rf.exists():
            content = rf.read_text(encoding="utf-8")
            # Extract run_id from GPT reply
            m = re.search(r'run_id:\s*(\S+)', content)
            if m:
                gpt_run_id = m.group(1).strip()
                details[f"gpt_run_id_in_{result_file}"] = gpt_run_id
                if gpt_run_id != run_id:
                    errors.append(
                        f"GPT reply run_id ({gpt_run_id}) != submitted run_id ({run_id}) "
                        f"in {result_file}"
                    )

    return {
        "consistent": len(errors) == 0,
        "errors": errors,
        "details": details,
    }


def main():
    parser = argparse.ArgumentParser(description="Validate run_id consistency across pack artifacts")
    parser.add_argument("--report-dir", required=True, help="Path to task report directory")
    args = parser.parse_args()

    result = validate_run_id_consistency(args.report_dir)
    import json
    print(json.dumps(result, indent=2, ensure_ascii=False))

    if result["consistent"]:
        print("\nRUN-ID CONSISTENT: All artifacts use the same run_id")
        sys.exit(0)
    else:
        print("\nRUN-ID INCONSISTENT:")
        for e in result["errors"]:
            print(f"  ERROR: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
