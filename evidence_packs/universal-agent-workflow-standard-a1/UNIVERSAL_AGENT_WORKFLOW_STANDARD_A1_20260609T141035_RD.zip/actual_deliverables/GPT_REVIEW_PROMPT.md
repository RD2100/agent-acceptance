## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1

You are reviewing the deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1**.

### Task Definition

Per the authorization from HUMAN-DECISION-RECORD-MANIFEST-CONTENT-CROSSCHECK-A1 R1 (accepted_with_limitation): Establish a universal agent workflow standard addressing recurring run_id inconsistencies and prompt template standardization across all hardening tasks.

### Deliverables

1. **`docs/AGENT_WORKFLOW_STANDARD.md`** (new, ~70 lines)
   - Agent Workflow Standard Protocol (AWSP) v1.0.0
   - Run-ID consistency rule across pack filename, run_id.txt, prompt {{RUN_ID}}, GPT reply
   - Evidence pack standard, prompt template standard, verification standard

2. **`scripts/validate_run_id_consistency.py`** (new, ~130 lines)
   - Validates run_id consistency across all pack artifacts
   - Detects hardcoded run_ids in prompt templates
   - Checks GPT reply run_id matches submitted run_id

3. **`tests/test_validate_run_id_consistency.py`** (7 tests)
   - Consistent artifacts, missing run_id file, hardcoded in prompt, R1 mismatch, GPT mismatch, GPT match, pack filename

### Review Criteria

1. **Run-ID Consistency**: Does the validator correctly detect all forms of run_id inconsistency?
2. **Protocol Standard**: Is AWSP v1.0.0 comprehensive enough to guide future tasks?
3. **Backward Compatibility**: Can the validator be applied to existing task reports?
4. **Test Coverage**: Are 7 tests sufficient?
5. **Practical Utility**: Will this validator prevent the recurring run_id mismatch issue?

### Expected Verdict Format

```
verdict: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
