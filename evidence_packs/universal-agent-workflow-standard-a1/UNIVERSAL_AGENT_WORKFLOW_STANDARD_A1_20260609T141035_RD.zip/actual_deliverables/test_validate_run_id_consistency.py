#!/usr/bin/env python3
"""test_validate_run_id_consistency.py — Tests for validate_run_id_consistency.py."""

import json
import sys
from pathlib import Path

import pytest

SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))

from validate_run_id_consistency import validate_run_id_consistency


class TestRunIdConsistency:
    """Tests for run_id consistency validation."""

    def test_consistent_artifacts(self, tmp_path):
        """All artifacts with matching run_id → consistent."""
        report_dir = tmp_path / "test-task-a1"
        report_dir.mkdir()
        run_id = "TEST_TASK_A1_20260609T120000_RD"

        (report_dir / "run_id.txt").write_text(run_id, encoding="utf-8")
        (report_dir / "R1_RUN_ID.txt").write_text(run_id, encoding="utf-8")
        (report_dir / "GPT_REVIEW_PROMPT.md").write_text(
            f"## Review\nrun_id: {{{{RUN_ID}}}}\n---END_OF_GPT_RESPONSE---\n",
            encoding="utf-8",
        )

        result = validate_run_id_consistency(str(report_dir))
        assert result["consistent"] is True
        assert result["errors"] == []

    def test_missing_run_id_file(self, tmp_path):
        """No run_id.txt → inconsistent."""
        report_dir = tmp_path / "test-task-a2"
        report_dir.mkdir()

        result = validate_run_id_consistency(str(report_dir))
        assert result["consistent"] is False
        assert any("run_id.txt not found" in e for e in result["errors"])

    def test_hardcoded_run_id_in_prompt(self, tmp_path):
        """Hardcoded run_id in prompt instead of {{RUN_ID}} → inconsistent."""
        report_dir = tmp_path / "test-task-a3"
        report_dir.mkdir()
        run_id = "TEST_TASK_A3_20260609T120000_RD"

        (report_dir / "run_id.txt").write_text(run_id, encoding="utf-8")
        (report_dir / "GPT_REVIEW_PROMPT.md").write_text(
            f"## Review\nrun_id: {run_id}\n---END_OF_GPT_RESPONSE---\n",
            encoding="utf-8",
        )

        result = validate_run_id_consistency(str(report_dir))
        assert result["consistent"] is False
        assert any("hardcoded run_id" in e for e in result["errors"])

    def test_r1_run_id_mismatch(self, tmp_path):
        """R1_RUN_ID.txt has different run_id → inconsistent."""
        report_dir = tmp_path / "test-task-a4"
        report_dir.mkdir()

        (report_dir / "run_id.txt").write_text("RUN_ID_A", encoding="utf-8")
        (report_dir / "R1_RUN_ID.txt").write_text("RUN_ID_B", encoding="utf-8")
        (report_dir / "GPT_REVIEW_PROMPT.md").write_text(
            "run_id: {{RUN_ID}}\n", encoding="utf-8"
        )

        result = validate_run_id_consistency(str(report_dir))
        assert result["consistent"] is False
        assert any("R1_RUN_ID.txt" in e for e in result["errors"])

    def test_gpt_reply_run_id_mismatch(self, tmp_path):
        """GPT reply has different run_id than submitted → inconsistent."""
        report_dir = tmp_path / "test-task-a5"
        report_dir.mkdir()
        run_id = "TEST_TASK_A5_20260609T120000_RD"

        (report_dir / "run_id.txt").write_text(run_id, encoding="utf-8")
        (report_dir / "GPT_REVIEW_PROMPT.md").write_text(
            "run_id: {{RUN_ID}}\n", encoding="utf-8"
        )
        (report_dir / "GPT_REVIEW_RESULT.txt").write_text(
            f"run_id: WRONG_RUN_ID_XYZ\nverdict: accepted\n",
            encoding="utf-8",
        )

        result = validate_run_id_consistency(str(report_dir))
        assert result["consistent"] is False
        assert any("GPT reply run_id" in e for e in result["errors"])

    def test_gpt_reply_run_id_matches(self, tmp_path):
        """GPT reply has same run_id → consistent."""
        report_dir = tmp_path / "test-task-a6"
        report_dir.mkdir()
        run_id = "TEST_TASK_A6_20260609T120000_RD"

        (report_dir / "run_id.txt").write_text(run_id, encoding="utf-8")
        (report_dir / "GPT_REVIEW_PROMPT.md").write_text(
            "run_id: {{RUN_ID}}\n", encoding="utf-8"
        )
        (report_dir / "GPT_REVIEW_RESULT.txt").write_text(
            f"run_id: {run_id}\nverdict: accepted\n",
            encoding="utf-8",
        )

        result = validate_run_id_consistency(str(report_dir))
        assert result["consistent"] is True

    def test_pack_filename_check(self, tmp_path):
        """Pack filename run_id matches → consistent."""
        report_dir = tmp_path / "test-task-a7"
        report_dir.mkdir()
        run_id = "TEST_TASK_A7_20260609T120000_RD"

        (report_dir / "run_id.txt").write_text(run_id, encoding="utf-8")
        (report_dir / "GPT_REVIEW_PROMPT.md").write_text(
            "run_id: {{RUN_ID}}\n", encoding="utf-8"
        )

        # Create pack directory with matching zip
        pack_dir = tmp_path.parent / "evidence_packs" / "test-task-a7"
        pack_dir.mkdir(parents=True, exist_ok=True)
        (pack_dir / f"{run_id}.zip").write_bytes(b"PK")

        result = validate_run_id_consistency(str(report_dir))
        assert result["details"].get("pack_filename") == run_id
