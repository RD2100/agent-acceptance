#!/usr/bin/env python3
"""
validate_context_memory.py — Privacy guard for context compression outputs.

Fail-closed: blocks any memory entry containing paper full text, raw transcript,
private user text, or secrets/tokens.
"""
import re
import sys
import json
import hashlib
from pathlib import Path

# ── Fail-closed patterns ──────────────────────────────────────────
# Keywords that indicate PRIVACY VIOLATION CONTENT (not documentation about safety rules)
# We use context-aware matching: skip lines that are clearly safety documentation.
FAIL_CLOSED_PATTERNS = [
    "real_paper_full_text",
    "raw_paper_text",
    "private_user_text",
    "raw_transcript",
    "博士论文正文",
    "用户论文全文",
    "外部上传",
]

# These patterns only flag if they appear as VALUES (key=value, key: value), not as
# documentation keywords in safety boundary lists.
SECRET_VALUE_PATTERNS = [
    (re.compile(r'\bapi[_-]?key\s*[:=]\s*\S+', re.I), "api_key"),
    (re.compile(r'\bsecret\s*[:=]\s*\S+', re.I), "secret"),
    (re.compile(r'\btoken\s*[:=]\s*\S{8,}', re.I), "token"),
    (re.compile(r'\bcookie\s*[:=]\s*\S+', re.I), "cookie"),
    (re.compile(r'\bsession\s*[:=]\s*\S{8,}', re.I), "session"),
    # Long base64-like strings that are NOT SHA256 hex hashes
    (re.compile(r'(?<![0-9a-fA-F])[A-Za-z0-9+/=]{40,}(?![0-9a-fA-F])'), "long_base64"),
]

# Lines matching these are safety documentation, not violations
SAFETY_CONTEXT_PATTERNS = re.compile(
    r'(禁止|不得|不允许|DO NOT|refuse|block|安全边界|safety|forbidden|prohibited'
    r'|fail.closed|永久禁止|严格禁止|never|绝不|should not|must not)',
    re.I,
)

# SHA256 hash pattern (64 hex chars) — these are evidence hashes, not secrets
SHA256_PATTERN = re.compile(r'\b[0-9a-fA-F]{64}\b')

# Explicitly allowed safe patterns
SAFE_PATTERNS = [
    "task_id",
    "review_run_id",
    "overall_judgment",
    "evidence_pack",
    "evidence_pack_sha256",
    "commit",
    "commit_hash",
    "安全边界",
    "流程教训",
    "implementation_commit",
    "pushed_to_github",
    "scope_limit",
]


def check_privacy(text: str, file_path: str = "") -> dict:
    """Check a text block for privacy violations. Context-aware: skips safety-doc lines."""
    issues = []
    lines = text.split("\n")

    # File-level pre-check: if the file is primarily safety documentation
    # (mentions safety keywords), then content markers in it are documentation, not violations.
    file_is_safety_doc = bool(SAFETY_CONTEXT_PATTERNS.search(text))

    # Phase 1: Check paper content markers — fail if they appear as content, not safety doc
    for pattern_str in FAIL_CLOSED_PATTERNS:
        for i, line in enumerate(lines):
            if pattern_str.lower() in line.lower():
                # Skip if this line is clearly safety documentation
                if SAFETY_CONTEXT_PATTERNS.search(line):
                    continue
                # Skip if the whole file is safety documentation
                if file_is_safety_doc:
                    continue
                # Also skip if it's a markdown header describing a safety rule
                if line.strip().startswith("#"):
                    continue
                # Skip bullet points in a safety-doc context (previous line had safety keyword)
                prev_line = lines[i-1].strip() if i > 0 else ""
                if line.strip().startswith("-") and SAFETY_CONTEXT_PATTERNS.search(prev_line):
                    continue
                issues.append({
                    "pattern": pattern_str,
                    "matches": [line.strip()[:80]],
                    "file": file_path,
                    "line": i + 1,
                })

    # Phase 2: Check secret value patterns — fail if they appear as key=value, not safety doc
    for pattern, name in SECRET_VALUE_PATTERNS:
        for i, line in enumerate(lines):
            match = pattern.search(line)
            if match:
                # Skip if the matched text is a SHA256 hash
                if SHA256_PATTERN.search(match.group(0)):
                    continue
                # Skip if line is safety documentation
                if SAFETY_CONTEXT_PATTERNS.search(line):
                    continue
                issues.append({
                    "pattern": name,
                    "matches": [match.group(0)[:60]],
                    "file": file_path,
                    "line": i + 1,
                })

    # Paper markers: only flag if present in content (not safety-doc lines)
    paper_issues = []
    for marker in FAIL_CLOSED_PATTERNS:
        for line in lines:
            if marker.lower() in line.lower():
                if not SAFETY_CONTEXT_PATTERNS.search(line) and not line.strip().startswith("#"):
                    paper_issues.append(marker)
                    break

    verdict = {
        "file": file_path,
        "pass": len(issues) == 0,
        "issues": issues,
        "paper_markers_detected": paper_issues,
        "char_count": len(text),
        "hash": hashlib.sha256(text.encode("utf-8")).hexdigest(),
    }
    return verdict


def validate_file(filepath: Path) -> dict:
    """Validate a single file for privacy issues."""
    try:
        text = filepath.read_text(encoding="utf-8")
    except Exception as e:
        return {
            "file": str(filepath),
            "pass": False,
            "issues": [{"pattern": "read_error", "matches": [str(e)]}],
            "paper_markers_detected": [],
            "char_count": 0,
            "hash": "",
        }
    return check_privacy(text, str(filepath))


def validate_directory(dirpath: Path, glob_pattern: str = "*.md") -> list:
    """Validate all matching files in a directory."""
    results = []
    for fp in sorted(dirpath.glob(glob_pattern)):
        results.append(validate_file(fp))
    return results


def main():
    targets = [
        Path("BOOT_CONTEXT.md"),
        Path("memory/index.md"),
        Path("memory/tasks"),
        Path("memory/knowledge"),
    ]

    all_results = []
    for target in targets:
        if not target.exists():
            continue
        if target.is_file():
            all_results.append(validate_file(target))
        elif target.is_dir():
            all_results.extend(validate_directory(target, "*.md"))

    if not all_results:
        print("NO FILES VALIDATED")
        sys.exit(1)

    # Report
    passed = sum(1 for r in all_results if r["pass"])
    failed = sum(1 for r in all_results if not r["pass"])

    print(f"=== PRIVACY GUARD REPORT ===")
    print(f"Files checked: {len(all_results)}")
    print(f"Passed: {passed}")
    print(f"Failed: {failed}")

    for r in all_results:
        status = "PASS" if r["pass"] else "FAIL"
        print(f"  [{status}] {r['file']} ({r['char_count']} chars, sha256={r['hash'][:16]}...)")
        if not r["pass"]:
            for issue in r["issues"]:
                print(f"    ISSUE: pattern={issue['pattern']}, matches={issue['matches']}")

    # Fail closed
    if failed > 0:
        print("\nFAIL CLOSED: Privacy violations detected. Aborting.")
        sys.exit(1)

    print("\nALL CLEAR: No privacy violations detected.")
    sys.exit(0)


if __name__ == "__main__":
    main()
