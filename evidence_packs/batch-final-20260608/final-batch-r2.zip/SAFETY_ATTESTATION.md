whole_dirty_tree_committed: false
dirty_baseline_protected: true (7 files)
guard_disabled: false
fail_closed_preserved: true
no_real_paper_content: true (all synthetic)
all_tests_green: true
