# PACK_MANIFEST — UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1

| Field | Value |
|-------|-------|
| task_id | UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1 |
| run_id | UNIVERSAL_AGENT_WORKFLOW_STANDARD_CROSS_PROJECT_SCAFFOLD_A1_20260609T145817_RD |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\universal-agent-workflow-standard-cross-project-scaffold-a1\EXECUTION_REPORT.md` | core | `004c37827e08f1ef…` | 2192 |
| 2 | `_reports\universal-agent-workflow-standard-cross-project-scaffold-a1\GPT_REVIEW_PROMPT.md` | core | `cdf15d77858815ef…` | 2620 |
| 3 | `scripts\validate_run_id_consistency.py` | deliverable | `9daa6c6292cd09b1…` | 9813 |
| 4 | `scripts\awsp_scaffold.py` | deliverable | `24df28de323c3f5d…` | 8379 |
| 5 | `tests\test_validate_run_id_consistency.py` | test | `3229a3857931210b…` | 9481 |
| 6 | `tests\test_cross_project_scaffold.py` | test | `48fd62b3d1ccf923…` | 11031 |
| 7 | `docs\AGENT_WORKFLOW_STANDARD.md` | documentation | `5b2a30f15b50e62d…` | 2996 |
| 8 | `PACK_MANIFEST.md` | core | self | - |

## Tests
- Suite: 520 passed
