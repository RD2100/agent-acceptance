## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1 R1

You are reviewing the R1 deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1**.

**Task ID**: {{TASK_ID}}
**Run ID**: {{RUN_ID}}

### Task Background

This task addresses 4 limitations from UNIVERSAL-AGENT-WORKFLOW-STANDARD-A1 R4:
1. validate_run_id_consistency.py was hardcoded to agent-acceptance project layout
2. No prompt-template validation (END_OF_GPT_RESPONSE marker, overall_judgment field)
3. No cross-project scaffold tool existed
4. No tests for these new features

### R1 Deliverables

1. **scripts/validate_run_id_consistency.py** (~195 lines, updated)
   - Added optional `config` dict parameter for cross-project evidence_pack_dir
   - Added prompt-template checks: END_OF_GPT_RESPONSE marker (check #8), overall_judgment field (check #9)
   - Extended GPT result file scanning to include R3 and R4 result files
   - CLI accepts `--evidence-pack-dir` argument
   - Backward compatible: existing callers unchanged

2. **scripts/awsp_scaffold.py** (~200 lines, new)
   - `create_scaffold(project_root, dry_run, force)`: Creates AWSP directory structure
   - `validate_scaffold(project_root)`: Validates existing structure
   - Generates: evidence_packs/, _reports/, docs/, scripts/, tests/, .awsp.json
   - Supports dry-run preview and force overwrite

3. **tests/test_cross_project_scaffold.py** (15 tests, new)
   - TestCrossProjectParameterization (3): explicit dir, nonexistent dir, cross-project layout
   - TestPromptTemplateValidation (4): missing END marker, missing overall_judgment, verdict-only, full compliant
   - TestAWSPScaffold (8): create, dry-run, validate, missing dirs, missing config, config content, force, nonexistent

4. **docs/AGENT_WORKFLOW_STANDARD.md** (updated to AWSP v1.1.0)
   - New sections: cross-project support, parameterized validator, scaffold tool
   - Version history table

### Validation Results

- **New tests**: 15 passed / 15 total
- **Full suite**: 520 passed / 520 total
- **AWSP version**: v1.1.0 (upgraded from v1.0.0)

### Review Criteria

1. Cross-project parameterization works for non-standard layouts?
2. Prompt-template validation catches missing END marker and overall_judgment?
3. Scaffold tool creates valid AWSP structure?
4. All 15 new tests sufficient?
5. Full suite 520 tests pass?

### Expected Verdict Format

```
overall_judgment: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
