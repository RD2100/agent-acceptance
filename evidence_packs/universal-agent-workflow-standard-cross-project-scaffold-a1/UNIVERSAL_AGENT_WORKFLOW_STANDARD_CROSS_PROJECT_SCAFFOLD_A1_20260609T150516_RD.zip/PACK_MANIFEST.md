# PACK_MANIFEST — UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1

| Field | Value |
|-------|-------|
| task_id | UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1 |
| run_id | UNIVERSAL_AGENT_WORKFLOW_STANDARD_CROSS_PROJECT_SCAFFOLD_A1_20260609T150516_RD |

## Files

| # | Path | Role | SHA-256 | Size |
|---|------|------|---------|------|
| 1 | `_reports\universal-agent-workflow-standard-cross-project-scaffold-a1\EXECUTION_REPORT.md` | core | `c9ad534db43c1555…` | 1462 |
| 2 | `_reports\universal-agent-workflow-standard-cross-project-scaffold-a1\GPT_REVIEW_PROMPT.md` | core | `a27c6f633fb7117a…` | 2901 |
| 3 | `scripts\validate_run_id_consistency.py` | deliverable | `44ab7ebe5433f8a0…` | 9790 |
| 4 | `scripts\awsp_scaffold.py` | deliverable | `89cf01ccf0ca5e3b…` | 9871 |
| 5 | `tests\test_validate_run_id_consistency.py` | test | `3229a3857931210b…` | 9481 |
| 6 | `tests\test_cross_project_scaffold.py` | test | `669ab827e01f5f48…` | 14248 |
| 7 | `docs\AGENT_WORKFLOW_STANDARD.md` | documentation | `5b2a30f15b50e62d…` | 2996 |
| 8 | `PACK_MANIFEST.md` | core | self | - |

## Tests
- Suite: 526 passed
