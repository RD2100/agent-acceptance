## GPT Review Prompt — UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1 R2

You are reviewing the R2 deliverables for task **UNIVERSAL-AGENT-WORKFLOW-STANDARD-CROSS-PROJECT-SCAFFOLD-A1**.

**Task ID**: {{TASK_ID}}
**Run ID**: {{RUN_ID}}

### R1 Blocking Issues Fixed

1. **Strict verdict check**: `validate_run_id_consistency.py` now flags any bare `verdict:` at the start of a line, even when `overall_judgment:` is also present. Previously it only flagged `verdict:` when `overall_judgment:` was absent. New test `test_bare_verdict_with_overall_judgment_fails` covers this.

2. **Enhanced validate_scaffold**: `awsp_scaffold.py` `validate_scaffold()` now checks `.awsp.json` content:
   - awsp_version matches the current AWSP version constant
   - Required config fields: awsp_version, project_root, directories, validation
   - Validation section: all 5 required checks (require_run_id_consistency, require_evidence_pack, require_prompt_template_vars, require_end_marker, require_overall_judgment)
   - 4 new tests: valid_scaffold_passes, version_mismatch_fails, missing_config_fields_fails, missing_validation_section_fails

### R2 Deliverables

1. **scripts/validate_run_id_consistency.py** (~195 lines)
   - R1 features: parameterized config, prompt-template checks (END marker, overall_judgment)
   - R2: strict verdict check (bare verdict: always fails)
   - 14 tests in test_validate_run_id_consistency.py

2. **scripts/awsp_scaffold.py** (~210 lines)
   - R1 features: create_scaffold, validate_scaffold (basic checks)
   - R2: validate_scaffold content checks (version, fields, validation config)
   - 18 tests in test_cross_project_scaffold.py

3. **tests/test_cross_project_scaffold.py** (21 tests total)
   - TestCrossProjectParameterization (3): explicit dir, nonexistent, cross-project layout
   - TestPromptTemplateValidation (4): missing END marker, missing overall_judgment, verdict-only, full compliant
   - TestAWSPScaffold (8): create, dry-run, validate, missing dirs, missing config, config content, force, nonexistent
   - TestValidateScaffoldContent (4): valid passes, version mismatch, missing fields, missing validation section
   - TestStrictVerdictCheck (2): bare verdict with overall_judgment fails, overall_judgment only passes

4. **docs/AGENT_WORKFLOW_STANDARD.md** — AWSP v1.1.0

### Validation Results

- **Target tests**: 35 passed / 35 total
- **Full suite**: 526 passed / 526 total

### Review Criteria

1. Strict verdict check catches bare verdict: even with overall_judgment:?
2. Enhanced validate_scaffold validates .awsp.json content?
3. All 21 scaffold tests sufficient?
4. Full suite 526 tests pass?

### Expected Verdict Format

```
overall_judgment: accepted | accepted_with_limitation | blocked | human_required
run_id: {{RUN_ID}}
findings: [list key findings]
next_task_authorization: [next task or "none"]
---END_OF_GPT_RESPONSE---
```
