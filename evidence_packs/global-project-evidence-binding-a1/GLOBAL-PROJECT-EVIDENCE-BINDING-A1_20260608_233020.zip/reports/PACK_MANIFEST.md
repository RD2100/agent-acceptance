# Pack Manifest

- task_id: GLOBAL-PROJECT-EVIDENCE-BINDING-A1
- run_id: GLOBAL_EVIDENCE_BINDING_A1_20260608_232904
- generated_at: 2026-06-08T15:29:04.926291+00:00

| Path | SHA256 | Bytes |
|---|---|---:|
| `actual_deliverables/CHANGED_FILES_EVIDENCE.md` | `776ea7fc205a4eca9fae70504796a7537abb597b524e093fe56b29b3fd3d6c6c` | 10261 |
| `actual_deliverables/PROTECTED_LEGACY_FILES_STATUS.md` | `dc491e7be905418c3f3d03bd9361ab6c07db058c06b76a2107ba3d05b740928d` | 1454 |
| `actual_deliverables/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.md` | `a6009e9d94e885fe92f26d5d82ccd8e49d862c2b4d160da05e232fa82b2c834b` | 5931 |
| `CLOSURE_REPORT.md` | `f2f45bdedba528cccdcd932dc2d54c178f47366020d9e7e602b35c5e97ecde2d` | 1145 |
| `GPT_REVIEW_PROMPT.md` | `1d35652946fd0481bd7820b1907d6385704eb1c2be447d3dd686ca316259ab2d` | 1174 |
| `reports/CHANGED_FILES_EVIDENCE.json` | `85edbd7ebda1aa9eac3383ba4875960113014918dc6e9a373765421118592a8e` | 10219 |
| `reports/CHANGED_FILES_EVIDENCE.md` | `776ea7fc205a4eca9fae70504796a7537abb597b524e093fe56b29b3fd3d6c6c` | 10261 |
| `reports/EXPANDED_ZIP_SAFETY_SCAN.json` | `10653eee930f467f45db9bad117d06b81105440b6feab22156ff9c873a6e651d` | 7392 |
| `reports/EXPANDED_ZIP_SAFETY_SCAN.md` | `e5d0198b72f253668dd6d13d14fec2b84001bcda9bc6b45214cea11e90739c59` | 241 |
| `reports/GIT_STATUS_EVIDENCE.txt` | `8e622a908eb3567af671c616ea989d26338ca101692fa283bd422bfd4f3c4bfa` | 15264 |
| `reports/PROTECTED_LEGACY_FILES_STATUS.json` | `6a6919dd5918a992e299ffdb1a325b4df8f362d06a421d301a50a6df32254a73` | 5031 |
| `reports/PROTECTED_LEGACY_FILES_STATUS.md` | `dc491e7be905418c3f3d03bd9361ab6c07db058c06b76a2107ba3d05b740928d` | 1454 |
| `reports/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.json` | `dff251b937aa6fbdfe9d6760f89a39f02dbcffdecad169b4249a1f87825723ef` | 5875 |
| `reports/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.md` | `a6009e9d94e885fe92f26d5d82ccd8e49d862c2b4d160da05e232fa82b2c834b` | 5931 |
| `SAFETY_ATTESTATION.md` | `e76c0df8201aea21d9d47400c0fe00fb94ae53325a99d3dcca32f3b27d4b0745` | 302 |
| `source_evidence/_reports/global-project-handoff-repair-a1/EXECUTION_REPORT.md` | `592ceab088aa76dd3c06219f605f23365af4d33081927b6bceeafe87f0cbcdd4` | 3028 |
| `source_evidence/_reports/global-project-handoff-repair-a1/GPT_REVIEW_RECORD.json` | `d3bdf606b2c89d47fc67b08da2118bfe41af2d3f24e525288b1e28ae3bdb53d8` | 2151 |
| `source_evidence/_reports/global-project-handoff-repair-a1/PACK_MANIFEST.md` | `01eab1792f5bae1f73ff9c610056059589511a9e0fdd3716ebcc6d9ec23d1b9c` | 3196 |
| `source_evidence/_reports/global-project-handoff-repair-a1/PRE_GPT_GATE_OUTPUT.txt` | `930565ffbc91c755f47ce260cdd232b678030a13d9d919347e8258a757395527` | 426 |
| `source_evidence/_reports/global-project-handoff-repair-a1/SAFETY_SCAN.md` | `5c75ee5ac089f4d0cb0eb0a31a139e3996bb43d24a1b656fd720f853fa7b405e` | 180 |
| `source_evidence/_reports/global-project-handoff-repair-a1/TARGETED_TEST_OUTPUT.txt` | `a88173d87fb232b48a2a90337fe230ee6a959f4570438febe973bce3b6b95cf6` | 262 |
| `source_evidence/_reports/global-project-handoff-repair-a1/VERIFY_GPT_REPLY_OUTPUT.txt` | `c260c4d4bdf131df08070fe8d33392812254d5d7246a0035ede457087d5b8955` | 1388 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_MODULE_STATUS.json` | `1bd7908a3af74df4bd6a5e7ee7a6f5f6730ef73aba02ea7c98156728aaa66766` | 10248 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_SOURCE_OF_TRUTH_MAP.json` | `19905e67827cbd7689b9cd3040b55c6ac11d59997caf676c7114b831a1e9cb72` | 4798 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_STALE_CLAIMS_REGISTER.json` | `a8c52279844639ba7773d2008f8e7ce5b5694dfa3b00a463d2fa070397a09230` | 1430 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_TEST_LEDGER.json` | `7bb6bdda9e792707bde09453ded1f70cadc90db96f30af5568337e9bde441166` | 1042 |
| `source_evidence/HANDOFF_APPROVAL_RECORD.json` | `1a008db43ecb45826c8166d181095613143aabe26cf40f94386798b3bdb8dc9f` | 1757 |
| `source_evidence/HANDOFF_SOURCE_OF_TRUTH.md` | `6fac2b229a4207a05bf45719ae3d78a252fe21e18e6285851be53b809674e3c2` | 3119 |
