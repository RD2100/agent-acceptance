# Expanded ZIP Safety Scan

- scanned_file_count: 31
- pass: True

## Findings
- none
