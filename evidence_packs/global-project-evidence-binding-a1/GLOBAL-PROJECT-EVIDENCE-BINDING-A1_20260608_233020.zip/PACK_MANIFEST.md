# Pack Manifest

- task_id: GLOBAL-PROJECT-EVIDENCE-BINDING-A1
- run_id: GLOBAL_EVIDENCE_BINDING_A1_20260608_233019
- generated_at: 2026-06-08T15:30:19.533243+00:00

| Path | SHA256 | Bytes |
|---|---|---:|
| `actual_deliverables/CHANGED_FILES_EVIDENCE.md` | `2e2eaf5e4a5b5b8f7224844b0f1c0371e88e757c9d52834f8d9d4bcb3f95b101` | 10379 |
| `actual_deliverables/PROTECTED_LEGACY_FILES_STATUS.md` | `c86a2485ecffde1db211027f856af067702f22651e98e0be495a686bd078ac0b` | 1439 |
| `actual_deliverables/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.md` | `1a12bc73bfcc477b0bdf82605dfaff0d6fc995d3685370c98cb817440e893e81` | 5931 |
| `CLOSURE_REPORT.md` | `2d885e94f5d94efc3627256035a324ae9f7738eeb0fa0da039ef9cf49614413c` | 1145 |
| `GPT_REVIEW_PROMPT.md` | `ffcda13a17153eb82a8ce4c6a8c1c1e8fca993565f565c0879cc5fbe9183d58b` | 1174 |
| `reports/CHANGED_FILES_EVIDENCE.json` | `d4b39dfeeb35c7e0e23936571d69e98f52ed55113d1513c19ea85cda913a30b8` | 10337 |
| `reports/CHANGED_FILES_EVIDENCE.md` | `2e2eaf5e4a5b5b8f7224844b0f1c0371e88e757c9d52834f8d9d4bcb3f95b101` | 10379 |
| `reports/EXECUTION_REPORT.md` | `483b5b8bfdd1e3a8696927e90e7005a8213f30d5c1027ca1be654e413ecce2e7` | 1812 |
| `reports/EXPANDED_ZIP_SAFETY_SCAN.json` | `4ce6e92d505368137d4bb541832e5b6884f55008d40963a1b47a6e9dcbd533c2` | 7748 |
| `reports/EXPANDED_ZIP_SAFETY_SCAN.md` | `4e1feec5c43bedc9808edb7c170c7d206131733b0716d4d13ed51194dd67ebcd` | 93 |
| `reports/GIT_STATUS_EVIDENCE.txt` | `717968bfbe71c000bc4bf3b84264d9d32bcd8d432cfc5ee0bbf36678c7066a90` | 15472 |
| `reports/PACK_MANIFEST.md` | `b1f041d6f6ee55f54ca77fb13df111f47097be14cae5f7b7bebec5c1c9b01b48` | 4139 |
| `reports/PROTECTED_LEGACY_FILES_STATUS.json` | `5861a304b1c208b9eb1fb917adc465531090099f51873cd2ba5ca5fd704397b2` | 7240 |
| `reports/PROTECTED_LEGACY_FILES_STATUS.md` | `c86a2485ecffde1db211027f856af067702f22651e98e0be495a686bd078ac0b` | 1439 |
| `reports/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.json` | `ed7a827a32b63976efd3e4bb8943b9a11c07e8211451464c46997b2890321d4f` | 5875 |
| `reports/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.md` | `1a12bc73bfcc477b0bdf82605dfaff0d6fc995d3685370c98cb817440e893e81` | 5931 |
| `reports/ZIP_RECORD.json` | `63b089006d1be21fc0130e70a78125c3dab71d2ed754de34bf7babeb69afbd4a` | 379 |
| `SAFETY_ATTESTATION.md` | `e76c0df8201aea21d9d47400c0fe00fb94ae53325a99d3dcca32f3b27d4b0745` | 302 |
| `source_evidence/_reports/global-project-handoff-repair-a1/EXECUTION_REPORT.md` | `592ceab088aa76dd3c06219f605f23365af4d33081927b6bceeafe87f0cbcdd4` | 3028 |
| `source_evidence/_reports/global-project-handoff-repair-a1/GPT_REVIEW_RECORD.json` | `d3bdf606b2c89d47fc67b08da2118bfe41af2d3f24e525288b1e28ae3bdb53d8` | 2151 |
| `source_evidence/_reports/global-project-handoff-repair-a1/PACK_MANIFEST.md` | `01eab1792f5bae1f73ff9c610056059589511a9e0fdd3716ebcc6d9ec23d1b9c` | 3196 |
| `source_evidence/_reports/global-project-handoff-repair-a1/PRE_GPT_GATE_OUTPUT.txt` | `930565ffbc91c755f47ce260cdd232b678030a13d9d919347e8258a757395527` | 426 |
| `source_evidence/_reports/global-project-handoff-repair-a1/SAFETY_SCAN.md` | `5c75ee5ac089f4d0cb0eb0a31a139e3996bb43d24a1b656fd720f853fa7b405e` | 180 |
| `source_evidence/_reports/global-project-handoff-repair-a1/TARGETED_TEST_OUTPUT.txt` | `a88173d87fb232b48a2a90337fe230ee6a959f4570438febe973bce3b6b95cf6` | 262 |
| `source_evidence/_reports/global-project-handoff-repair-a1/VERIFY_GPT_REPLY_OUTPUT.txt` | `c260c4d4bdf131df08070fe8d33392812254d5d7246a0035ede457087d5b8955` | 1388 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_MODULE_STATUS.json` | `1bd7908a3af74df4bd6a5e7ee7a6f5f6730ef73aba02ea7c98156728aaa66766` | 10248 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_SOURCE_OF_TRUTH_MAP.json` | `19905e67827cbd7689b9cd3040b55c6ac11d59997caf676c7114b831a1e9cb72` | 4798 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_STALE_CLAIMS_REGISTER.json` | `a8c52279844639ba7773d2008f8e7ce5b5694dfa3b00a463d2fa070397a09230` | 1430 |
| `source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_TEST_LEDGER.json` | `7bb6bdda9e792707bde09453ded1f70cadc90db96f30af5568337e9bde441166` | 1042 |
| `source_evidence/HANDOFF_APPROVAL_RECORD.json` | `1a008db43ecb45826c8166d181095613143aabe26cf40f94386798b3bdb8dc9f` | 1757 |
| `source_evidence/HANDOFF_SOURCE_OF_TRUTH.md` | `6fac2b229a4207a05bf45719ae3d78a252fe21e18e6285851be53b809674e3c2` | 3119 |
