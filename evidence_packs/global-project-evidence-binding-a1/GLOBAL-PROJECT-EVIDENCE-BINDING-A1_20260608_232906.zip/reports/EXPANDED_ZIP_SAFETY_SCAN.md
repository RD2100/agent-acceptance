# Expanded ZIP Safety Scan

- scanned_file_count: 26
- pass: False

## Findings
- `SAFETY_ATTESTATION.md`: [{'pattern': 'paper_fulltext_marker'}]
- `source_evidence/HANDOFF_SOURCE_OF_TRUTH.md`: [{'pattern': 'paper_fulltext_marker'}]
