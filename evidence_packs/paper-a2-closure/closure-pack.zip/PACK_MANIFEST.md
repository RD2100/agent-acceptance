# Evidence Pack - PAPER-A2
created_at: 2026-06-06T09:01:28Z
files_count: 16

| path | role | sha256 |
|------|------|--------|
| BYPASS_CHECK_OUTPUT.txt | evidence | ef25ddd2c78a019ce18b4a3cc9b04f6b7a92e085335f73526fa863885771f3fc |
| CLOSURE_REPORT.md | evidence | 4881a8e1f6eb8e4899e8cf6e0ad1ecb849674f8941a8aed6ca0c48ef0ce6386c |
| GPT_REVIEW_PROMPT.md | evidence | c1736482c6ceb600e7c5863c514261006fba15d555a7de34f0a707e5561e283f |
| SAFETY_ATTESTATION.md | evidence | 7a92b7b843b93d7274e4188c60e74386eb88439a595c1dc18a8032f6e8f0be75 |
| TEST_OUTPUT.txt | evidence | 7644ed99c68519e58ef0f54520c3f61f237ab4e1e80d7f47389ccba540e662fe |
| contracts/paper_redacted_evidence_pack_contract.yaml | deliverable | fca8d65e7a189b44a07433b55d043843bfac1cd8b8ac9d40afb9aa26bf0aeaa0 |
| contracts/paper_task_io_contract.yaml | deliverable | fe909542e47de8b584b82776cb51e2da112c1869987119cafb30864e6bf9f473 |
| docs/paper-task-io-protocol.md | deliverable | c6f4d241e9094d8ed511f5372d73f45a76217ab5edcab8ea613f7b238af0677b |
| examples/PAPER_TASK_INPUT.yaml | deliverable | ada47b8c3dad3c5cbcecf4b0b4872cc8af601738d0e40c5bb094fdb8c88be918 |
| examples/PAPER_TASK_OUTPUT.yaml | deliverable | 8efceca3fef5af80da9323bd5f8e87e65675181fbed3010c176f93acac11b54f |
| examples/PRIVACY_ATTESTATION.yaml | deliverable | 6ed25600dee36eb87b642fd605d9c78d8fd6520aa2390aee82d21ed5b6b24201 |
| schemas/paper_redacted_evidence_pack.schema.json | deliverable | bb2064f473ec1617a65d9130a31931002bb9e3f3d7ffc3cad15480ef7000cc76 |
| schemas/paper_task_input.schema.json | deliverable | 39aeb395dd756e95b927d106347b640879b29cb5a3e86444fde3b4c9b79f7725 |
| schemas/paper_task_output.schema.json | deliverable | 49aca4e3ba6799369a12f2155898a6b2bdbb0c5ec3c1ae1078f28212b9195252 |
| tests/test_paper_privacy_boundaries.py | deliverable | 6c0b9ec30a154ebdd83388e57e2d4d8d3d4a96dae64bee19ded317a0d3f47194 |
| PACK_MANIFEST.md | pack_manifest | self_excluded |

manifest_valid: true
