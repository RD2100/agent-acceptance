# Evidence Pack - PAPER-A2 R2
created_at: 2026-06-06T09:05:17Z
files_count: 17

| path | role | sha256 |
|------|------|--------|
| BYPASS_CHECK_OUTPUT.txt | evidence | ef25ddd2c78a019ce18b4a3cc9b04f6b7a92e085335f73526fa863885771f3fc |
| CLOSURE_REPORT.md | evidence | 507360c686f8ed97169ae19b6757f4d7c7503bdd4547353eef91128d6ab85db2 |
| GPT_REVIEW_PROMPT.md | evidence | 808fcdfe5bd40497a7b26acd67084f5d4b47b3fed3dcf5d102032adb2e20fb66 |
| SAFETY_ATTESTATION.md | evidence | e28b6df30276c4ddd065a14b3ed484fe2e85b8732f1a01f30b5d0c86badd98c7 |
| TEST_OUTPUT.txt | evidence | 15f2b84110b044d6254392b186dfe982c1417e8c13c44e57412709356755527e |
| contracts/paper_redacted_evidence_pack_contract.yaml | deliverable | fca8d65e7a189b44a07433b55d043843bfac1cd8b8ac9d40afb9aa26bf0aeaa0 |
| contracts/paper_task_io_contract.yaml | deliverable | fe909542e47de8b584b82776cb51e2da112c1869987119cafb30864e6bf9f473 |
| docs/paper-task-io-protocol.md | deliverable | c6f4d241e9094d8ed511f5372d73f45a76217ab5edcab8ea613f7b238af0677b |
| examples/paper_a2_synthetic_case/PAPER_TASK_INPUT.yaml | deliverable | ada47b8c3dad3c5cbcecf4b0b4872cc8af601738d0e40c5bb094fdb8c88be918 |
| examples/paper_a2_synthetic_case/PAPER_TASK_OUTPUT.yaml | deliverable | 8efceca3fef5af80da9323bd5f8e87e65675181fbed3010c176f93acac11b54f |
| examples/paper_a2_synthetic_case/PRIVACY_ATTESTATION.yaml | deliverable | 6ed25600dee36eb87b642fd605d9c78d8fd6520aa2390aee82d21ed5b6b24201 |
| examples/paper_a2_synthetic_case/REDACTION_REPORT.yaml | deliverable | 218dcd3792e4bed8a1bd25588ddf93e2ae23fed0339baea19c26f0593156fe39 |
| schemas/paper_redacted_evidence_pack.schema.json | deliverable | 475433b04a98f9be5c9735cb2fd23648c271f63ab877be35bfa220dbae087e7a |
| schemas/paper_task_input.schema.json | deliverable | 39aeb395dd756e95b927d106347b640879b29cb5a3e86444fde3b4c9b79f7725 |
| schemas/paper_task_output.schema.json | deliverable | 49aca4e3ba6799369a12f2155898a6b2bdbb0c5ec3c1ae1078f28212b9195252 |
| tests/test_paper_privacy_boundaries.py | deliverable | 44ca2de6475021fd0769e81aa742911fc38d3630244efd77b03b9b6b16135123 |
| PACK_MANIFEST.md | pack_manifest | self_excluded |

manifest_valid: true
