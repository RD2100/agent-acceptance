| path | bytes | sha256 |
|---|---:|---|
| CLOSURE_REPORT.md | 1440 | 37f30d07a18d8228af4cf57382e97eabbfa6c2d71d3cc5e1281555fbe7b0da65 |
| GPT_REVIEW_PROMPT.md | 1038 | 86a480a41a0d1d7cf90935fb4b0bee8b8286f692af70ac825d61a7aab5fe3ecf |
| SAFETY_ATTESTATION.md | 511 | 7b5343fddfb91721c72471db001c083f243cec4296302f2e0c29b7629051091c |
| actual_deliverables/ai_guard.py | 16389 | b91a825e2ac558419d584bfcf05ef779ee89a54f57d63f791b1e80732a8309dd |
| actual_deliverables/context-compression-a1.yaml | 2915 | ff4173877424bce043f459cb39e0e142510058ad15844be45497df97b2226334 |
| actual_deliverables/test_ai_guard_staged_scope.py | 3194 | 554c1dffc54007476ee3b2c3b55a0be02c72b366924b61a0469d8624ccf3cfb3 |
| reports/AI_GUARD_TASK_MODE_OUTPUT.txt | 134 | 33c52fc18bb7af171e3d4339086a20f2d92e55452d26204a1b8a4fb4206c1895 |
| reports/FULL_TEST_OUTPUT.txt | 11279 | 3ba3f492f797db137f43a6332aabbff8dbba256bb5e74b5c88cb6f01197156ab |
| reports/TARGETED_TEST_OUTPUT.txt | 1534 | d91f4eab388bf36cdf6df3a44c0dda454fc8404d9c29db5c1cdd5fd2748d643a |
| PACK_MANIFEST.md | self | self_excluded |
