"""Test ai_guard task mode uses staged files for scope, full tree for security."""
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
AI_GUARD = REPO_ROOT / "tools" / "ai_guard.py"


def run_guard(*args):
    """Run ai_guard.py and return (exit_code, stdout, stderr)."""
    result = subprocess.run(
        [sys.executable, str(AI_GUARD)] + list(args),
        capture_output=True, text=True, cwd=str(REPO_ROOT),
    )
    return result.returncode, result.stdout, result.stderr


class TestStagedMode:
    """Staged mode must continue to work correctly."""

    def test_staged_mode_runs(self):
        """staged mode should run with staged files."""
        exit_code, stdout, stderr = run_guard("staged")
        # staged mode should not error on infrastructure
        lines = stdout.splitlines()
        # It should output something (either PASS, BLOCKED, or errors)
        assert len(lines) > 0, "staged mode produced no output"


class TestTaskModeStagedScope:
    """Task mode scope checks must use staged files, not entire working tree."""

    def test_task_mode_git_diff_cached_for_scope(self):
        """Task mode must git diff --cached for scope, not git diff HEAD."""
        # Verify by running task mode and checking it doesn't flag
        # known dirty-worktree files that are NOT staged
        exit_code, stdout, stderr = run_guard(
            "task", str(REPO_ROOT / ".ai" / "tasks" / "context-compression-a1.yaml")
        )
        # Task mode should NOT error on unstaged dirty baseline
        # (those files aren't staged, so scope check shouldn't flag them)
        for line in stdout.splitlines():
            if "SCOPE:" in line and any(
                dirty in line for dirty in [
                    "HANDOFF_REPLY_V4",
                    "archive/draft-hooks",
                    "runs/project-history-gaps",
                    "runs/repo-routing",
                ]
            ):
                assert False, (
                    f"Task mode flagged unstaged dirty file: {line}\n"
                    "Scope check must use staged files only."
                )


class TestDenyScanStillFull:
    """Deny_paths and secret scan must still check all changed files."""

    def test_deny_mode_still_scans_full_working_tree(self):
        """Deny checks must use git diff HEAD (all working tree changes)."""
        # The ai_guard code has been verified to use 'changed_all' for
        # deny_paths and secret scanning. This is a structural test.
        code = AI_GUARD.read_text(encoding="utf-8")
        assert "changed_all" in code, "ai_guard must define changed_all for task mode"
        assert "scan_security" in code, "ai_guard must use separate security scan set"


class TestFailClosed:
    """Ensure staged forbidden content still fails closed."""

    def test_smoke_fail_closed(self):
        """Guard must still exist and run."""
        assert AI_GUARD.exists(), "ai_guard.py must exist"
        code = AI_GUARD.read_text(encoding="utf-8")
        assert "sys.exit(1)" in code, "Guard must have fail-closed exit(1)"
        assert "BLOCKED" in code, "Guard must retain BLOCKED output"
