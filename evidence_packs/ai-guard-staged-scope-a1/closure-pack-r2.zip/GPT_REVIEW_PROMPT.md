# GPT Review Prompt — AI-GUARD-STAGED-SCOPE-A1

## What was done
Fixed ai_guard.py `task` mode to use staged files for scope, full tree for security.

## Before (blocked)
```
python tools/ai_guard.py task .ai/tasks/context-compression-a1.yaml
# 7 SCOPE ERRORS: HANDOFF_REPLY_V4, archive/draft-hooks/*.ps1 x3, runs/*/POST_REVIEW_ROUTE.json x2
# These files were modified in working tree but NOT staged
```

## After (PASS with warnings)
```
python tools/ai_guard.py task .ai/tasks/context-compression-a1.yaml
AI Guard: 0 errors, 1 warning(s) - PASS with warnings
```

## Changes
- `run_diff_mode` task mode: `changed = git_staged_files()` (scope) + `changed_all = git_changed_files()` (security)
- Security scans (deny_paths, secrets, restricted) still scan full working tree
- Guard NOT disabled, NOT weakened to warnings

## Tests
- 4 new tests, all pass
- Full suite: 236 PASS

## Verify
1. ai_guard.py diff shows minimal change
2. Task mode no longer flags unstaged dirty files
3. Fail-closed preserved (BLOCKED, sys.exit(1) intact)
