| path | bytes | sha256 |
|---|---:|---|
| CLOSURE_REPORT.md | 1544 | 40a7851257c08977e3c80dfda496920ba6666b4c53909c24a303ee73d0dfe435 |
| GPT_REVIEW_PROMPT.md | 1059 | 6913d5f096d77e5743aca3698c1ce48e891235be7af4b2f8b2a659be43307399 |
| GPT_REVIEW_RESULT.txt | 2371 | 4aa4854ae0bbdadfe72e621fb2132d6d27ddd39cab1cb802221c96fd6e414af3 |
| GPT_REVIEW_RESULT_R2.txt | 2371 | 4aa4854ae0bbdadfe72e621fb2132d6d27ddd39cab1cb802221c96fd6e414af3 |
| SAFETY_ATTESTATION.md | 511 | 7b5343fddfb91721c72471db001c083f243cec4296302f2e0c29b7629051091c |
| actual_deliverables/context-compression-a1.yaml | 2915 | ff4173877424bce043f459cb39e0e142510058ad15844be45497df97b2226334 |
| actual_deliverables/test_ai_guard_staged_scope.py | 6959 | 60f03c5a665f73fce05388131a89cc9ac868446f653232fe72148d162290b81a |
| actual_deliverables/tools/ai_guard.py | 16542 | 99fe9a3b6b4788e183e9f067fb1b55defbe2bf6b1c73b9978f1930b1315254aa |
| reports/AI_GUARD_TASK_MODE_OUTPUT.txt | 134 | 33c52fc18bb7af171e3d4339086a20f2d92e55452d26204a1b8a4fb4206c1895 |
| reports/FULL_TEST_OUTPUT.txt | 11279 | a3c04d10f54960d91905f6ce96c3a30075d24ef8d26f49da7b1701f9a6491fd0 |
| reports/TARGETED_TEST_OUTPUT.txt | 1882 | b78457ab7db13f2e2a6d478361d2e34cd0d192bf20ea39185da3c28ccc3b6d59 |
| PACK_MANIFEST.md | self | self_excluded |
