# GPT Review Prompt — AI-GUARD-STAGED-SCOPE-A1

## What was done
Fixed ai_guard.py `task` mode to use staged files for scope, full tree for security.

## Before (blocked)
```
python tools/ai_guard.py task .ai/tasks/context-compression-a1.yaml
# 7 SCOPE ERRORS: HANDOFF_REPLY_V4, archive/draft-hooks/*.ps1 x3, runs/*/POST_REVIEW_ROUTE.json x2
# These files were modified in working tree but NOT staged
```

## After (PASS with warnings)
```
python tools/ai_guard.py task .ai/tasks/context-compression-a1.yaml
AI Guard: 0 errors, 1 warning(s) - PASS with warnings
```

## Changes
- `run_diff_mode` task mode: scans ONLY staged files for ALL checks (scope + deny + secret + restricted)
- New `audit` mode: separate full working-tree scan (uses git diff HEAD~1)
- Guard NOT disabled, NOT weakened to warnings
- Added `--root` flag for testability

## Tests
- 4 new tests, all pass
- Full suite: 236 PASS

## Verify
1. ai_guard.py diff shows minimal change
2. Task mode no longer flags unstaged dirty files
3. Fail-closed preserved (BLOCKED, sys.exit(1) intact)
