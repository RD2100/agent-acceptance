﻿# Queue Report: release-readiness-queue

**Time**: 2026-06-07T16:06:53.6366488+08:00
**Duration**: 2.7s
**Mode**: safe-batch

## Executive Decision

FAILED 鈥?escalate to reviewer for diagnosis.

## Summary
PASS=0 BLOCKED=0 FAILED=1 ESCALATED=0 SKIPPED=0 TOTAL=1

## Item Matrix

| # | Item ID | Status | Verdict | Duration | Reason |
|---|---------|--------|---------|----------|--------|
| 1 | q-release-readiness | failed | FAILED | 2.5s | exit code 2 |

## Next Action
Stop. Escalate failed items to reviewer.
