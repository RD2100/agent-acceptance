| path | bytes | sha256 |
|---|---:|---|
| BATCH_REVIEW_SUMMARY.md | 825 | 4474a4f1dc00ac04c1c83d490d7844e6b481baaef837aea910dd229dca943d4f |
| KEY_DIFFS.patch | 1563 | 6cedd1a85cca1e6e796a69afc11dd7eaf2b10e5f04fa9c69c46dbce8d36e89a6 |
| SAFETY_ATTESTATION.md | 112 | 18274d250c30d7c27bc56cff80971e3d6391d994ea799faef7e5f083e035a2e2 |
| PACK_MANIFEST.md | self | self_excluded |
