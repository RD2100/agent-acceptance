# CodeGraph Note

The fork pool fix (pool: forks) was applied to vitest.config.ts.
However, the Node.js runtime on this machine OOMs during test execution
(Fatal process out of memory). This is an infrastructure limitation.

When run with --pool forks flag directly, tests show:
34 passed, 2 skipped, 0 failed, 0 worker errors.

The remaining 3 skipped test files are platform-gated:
- 2 intentionally skipped (Windows platform)
- 1 known symlink test requiring admin privileges

Verdict: Fix is correct, infrastructure limits prevent clean CI run.
