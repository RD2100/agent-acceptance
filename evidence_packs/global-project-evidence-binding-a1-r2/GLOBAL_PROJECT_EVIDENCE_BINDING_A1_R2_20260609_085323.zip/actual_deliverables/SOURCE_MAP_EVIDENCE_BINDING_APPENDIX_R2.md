# Source Map Evidence Binding Appendix R2

```json
{
  "task_id": "GLOBAL-PROJECT-EVIDENCE-BINDING-A1-R2",
  "run_id": "GLOBAL_EVIDENCE_BINDING_A1_R2_20260609_085323",
  "generated_at": "2026-06-09T00:53:23.302760+00:00",
  "entries": [
    {
      "path": "HANDOFF_SOURCE_OF_TRUTH.md",
      "exists": true,
      "is_file": true,
      "sha256": "6fac2b229a4207a05bf45719ae3d78a252fe21e18e6285851be53b809674e3c2",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/HANDOFF_SOURCE_OF_TRUTH.md"
    },
    {
      "path": "HANDOFF_APPROVAL_RECORD.json",
      "exists": true,
      "is_file": true,
      "sha256": "1a008db43ecb45826c8166d181095613143aabe26cf40f94386798b3bdb8dc9f",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/HANDOFF_APPROVAL_RECORD.json"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/GPT_REVIEW_RECORD.json",
      "exists": true,
      "is_file": true,
      "sha256": "d3bdf606b2c89d47fc67b08da2118bfe41af2d3f24e525288b1e28ae3bdb53d8",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/GPT_REVIEW_RECORD.json"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/VERIFY_GPT_REPLY_OUTPUT.txt",
      "exists": true,
      "is_file": true,
      "sha256": "c260c4d4bdf131df08070fe8d33392812254d5d7246a0035ede457087d5b8955",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/VERIFY_GPT_REPLY_OUTPUT.txt"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/PRE_GPT_GATE_OUTPUT.txt",
      "exists": true,
      "is_file": true,
      "sha256": "930565ffbc91c755f47ce260cdd232b678030a13d9d919347e8258a757395527",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/PRE_GPT_GATE_OUTPUT.txt"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/EXECUTION_REPORT.md",
      "exists": true,
      "is_file": true,
      "sha256": "592ceab088aa76dd3c06219f605f23365af4d33081927b6bceeafe87f0cbcdd4",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/EXECUTION_REPORT.md"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/PACK_MANIFEST.md",
      "exists": true,
      "is_file": true,
      "sha256": "01eab1792f5bae1f73ff9c610056059589511a9e0fdd3716ebcc6d9ec23d1b9c",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/PACK_MANIFEST.md"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_SOURCE_OF_TRUTH_MAP.json",
      "exists": true,
      "is_file": true,
      "sha256": "19905e67827cbd7689b9cd3040b55c6ac11d59997caf676c7114b831a1e9cb72",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_SOURCE_OF_TRUTH_MAP.json"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_STALE_CLAIMS_REGISTER.json",
      "exists": true,
      "is_file": true,
      "sha256": "a8c52279844639ba7773d2008f8e7ce5b5694dfa3b00a463d2fa070397a09230",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_STALE_CLAIMS_REGISTER.json"
    },
    {
      "path": "_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_TEST_LEDGER.json",
      "exists": true,
      "is_file": true,
      "sha256": "7bb6bdda9e792707bde09453ded1f70cadc90db96f30af5568337e9bde441166",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-handoff-repair-a1/WHOLE_PROJECT_TEST_LEDGER.json"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1/GPT_REVIEW_RESULT.txt",
      "exists": true,
      "is_file": true,
      "sha256": "211d3f1e37d46a7c59bae055726ac865418877a5302b6a6b2eb486759a5a2509",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1/GPT_REVIEW_RESULT.txt"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1/VERIFY_GPT_REPLY_OUTPUT.txt",
      "exists": true,
      "is_file": true,
      "sha256": "d1159c64752016ca794e79769bd3019574b6abdcf6cc0b5c94cf6b0c962e3237",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1/VERIFY_GPT_REPLY_OUTPUT.txt"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1/CHANGED_FILES_EVIDENCE.json",
      "exists": true,
      "is_file": true,
      "sha256": "083e028484498ed549d853effcfd6b42b661fc13c93a12a777bf8247dcec9959",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1/CHANGED_FILES_EVIDENCE.json"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1/PROTECTED_LEGACY_FILES_STATUS.json",
      "exists": true,
      "is_file": true,
      "sha256": "ff5c0547f99e93c09878fcfa7b91dfcc1b845dc82c609c14f803bfcfee5090ad",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1/PROTECTED_LEGACY_FILES_STATUS.json"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.json",
      "exists": true,
      "is_file": true,
      "sha256": "d5dfbb5ef15c20a966ff3e1fe205e5feedb59e5854cec54373c49da697831f28",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1/SOURCE_MAP_EVIDENCE_BINDING_APPENDIX.json"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1-r2/GPT_HANDOFF_REPLY_V4_CONSULT_RESULT.txt",
      "exists": true,
      "is_file": true,
      "sha256": "803902de08abbec680f2c5945863585378a4ec74efddc48d7df3439bdb449de6",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1-r2/GPT_HANDOFF_REPLY_V4_CONSULT_RESULT.txt"
    },
    {
      "path": "_reports/global-project-evidence-binding-a1-r2/VERIFY_GPT_HANDOFF_REPLY_V4_CONSULT_OUTPUT.txt",
      "exists": true,
      "is_file": true,
      "sha256": "b3fc62ea6626393d12d534402955c9229dbeeb3c87be3bc0735a7c4e1824d4b3",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/_reports/global-project-evidence-binding-a1-r2/VERIFY_GPT_HANDOFF_REPLY_V4_CONSULT_OUTPUT.txt"
    },
    {
      "path": "evidence_packs/global-project-handoff-repair-a1/GLOBAL_PROJECT_HANDOFF_REPAIR_A1_20260608_223800.zip",
      "exists": true,
      "is_file": true,
      "sha256": "defe3a08596b9b48fbf01690bbf9395eceab6c04c606bd2b7e3372c5fe6c5eba",
      "embedded_in_pack": true,
      "copy_path_in_pack": "source_evidence/evidence_packs/global-project-handoff-repair-a1/GLOBAL_PROJECT_HANDOFF_REPAIR_A1_20260608_223800.zip"
    }
  ],
  "correction_from_a1": "R2 manifest will include every embedded source_evidence file, including the prior closure ZIP. No embedded_in_pack claim is made without a matching pack file and manifest row.",
  "limitations": [
    "HANDOFF_REPLY_V4.txt remains human_required_not_resolved.",
    "whole-project/global status remains partial / needs_more_evidence.",
    "production promotion remains not approved.",
    "296 PASS remains unverified."
  ]
}
```
