# Evidence Pack - ARCH-GAP-A1 Closure
pipeline_run_id: arch-gap-a1
created_at: 2026-06-06T04:21:29Z
files_count: 8

| path | role | sha256 |
|------|------|--------|
| BYPASS_CHECK_OUTPUT.txt | verification_output | ef25ddd2c78a019ce18b4a3cc9b04f6b7a92e085335f73526fa863885771f3fc |
| TEST_OUTPUT.txt | verification_output | 4023a486565f7f672086a4c3b7800466fe06a34fda3b48b4976147cabcbd37ad |
| contracts/framework_usage_contract.yaml | deliverable | 6b4e1f4c62138bd5e1aaa413341ab202ba8d85f60415a241126082508205c9a2 |
| docs/framework-usage-enforcement.md | deliverable | 477efaf46decb340b2c14b25cac56ac8c20081811df5a347c47115496a95d6c5 |
| docs/reference-paper-review-pipeline.md | deliverable | 549a4f66e7daa2dfe367790b86b1169b8683a2d33fb9e590127d5caba971530c |
| scripts/check_submission_bypass.py | deliverable | 396011793575ca8a185b5e3c43fc5427cbd33fbdecb16e4ccedfc8dde6c551fd |
| tests/test_framework_usage.py | deliverable | 9b37850a3b939d0033b39d3fc26094962366633c97c1e9cebce25b82f6535f3b |
| PACK_MANIFEST.md | pack_manifest | self_excluded |

manifest_valid: true
