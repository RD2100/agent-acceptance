real_paper_full_text_processed: false
no_forbidden_content: true
8_targeted_tests_pass: true
295_full_pass: true
