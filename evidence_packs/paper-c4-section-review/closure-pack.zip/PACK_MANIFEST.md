| path | bytes | sha256 |
|---|---:|---|
| SAFETY_ATTESTATION.md | 117 | d6da12c6f4a8611fd1d2dc056b2e3deb25f3e5c34733da89072e5b1c0baa68bb |
| actual_deliverables/paper_c4_section_packet_validator.py | 2134 | 9fb1efb1c3c5e0fff4d34470205ded83e8f0ac8f03353c43509bb7cdbf66a53d |
| actual_deliverables/paper_c4_section_review.py | 7348 | d1b657ac6ac7e4eaa00e255d694876e3d5a3e57fe3cf2989b5f015ab71c4f381 |
| actual_deliverables/paper_c4_section_review_input.schema.json | 931 | cde929d313505bf282fcab85254674be822f63ef1ab8a9dc54494111c8fef647 |
| actual_deliverables/paper_c4_section_review_result.schema.json | 1024 | 3618dea1dc2b490a1f672495f860028a1183295b065576897851c4d6f33b37e1 |
| actual_deliverables/test_paper_c4_section_review.py | 2131 | bcf371154ad71e1f867c7ff13700f8a3d678081492a88361b00750b0939bac79 |
| reports/GIT_STATUS.txt | 3315 | 51734ed0f5e641cf6382202eafb52091016253178bf79e502ae88a4ac4dc8480 |
| reports/SYNTHETIC_OUTPUT.txt | 1371 | a3737f896000f7fe4587b2b43b0e0d1cd8a04f7db77cf72b25eb781c1a071381 |
| reports/TARGETED_TEST_OUTPUT.txt | 1911 | 2dad8b732b3886ed43172e25db1e0f5d79ce735297ce003464012078217e20a6 |
| reports/TEST_OUTPUT.txt | 11360 | a9a56053e549038aa411e418238b3e9fc03d8710fa6f7727bf0812aa4bcbf62d |
| PACK_MANIFEST.md | self | self_excluded |
